/* Gulp file */

'use strict';

// 1. LOAD PLUGINS

const gulp       = require('gulp');
const env        = require('dotenv').config();
const del        = require('del');
const minCss     = require('gulp-clean-css');
const minJs	     = require('gulp-uglify');
const concat     = require('gulp-concat');
const replace    = require('gulp-html-replace');
const ftp        = require('vinyl-ftp');
const gutil	     = require('gulp-util');
const babel      = require('gulp-babel');
const rev        = require('gulp-rev');
const revReplace = require('gulp-rev-replace');
const imagemin   = require('gulp-imagemin');
const sourcemaps = require('gulp-sourcemaps');
const postcss    = require('gulp-postcss');
const autoprefixer = require('autoprefixer');
const cssclean   = require('postcss-clean');
//var watch     = require('gulp-watch');
//const less = require('gulp-less');
//const compiler = require('google-closure-compiler-js').gulp();


// 2. CONFIGURATION

const paths = {
	dist: "./dist",
	app:  'site/wp-content/themes/news-faking-fluency',
};


// 3. TASKS

gulp.task('less:build', function () {
	return gulp.src('app/public/css/main.less')
		.pipe(less())
		.on('error', function (error) {
			console.log(error.toString());
			this.emit('end');
		})
		.pipe(gulp.dest('app/public/css'));
});

gulp.task('watch:less', gulp.series('less:build', function () {
	return gulp.watch("app/**/*.less").on('change', gulp.series('less:build'));
}));

// Delete build and temporary folders
gulp.task('clean', function() {
	return del(['dist/**', '!dist']);
});

// Copy app to distribution folder
gulp.task('copy:app',
	gulp.series('clean', function copy_root_folder() {
		return gulp.src(paths.app + "/**", { dot:true })
		.pipe(gulp.dest(paths.dist + "/"));
	})
);


// 3.1 CSS TASKS

// Minify and concat css
gulp.task('css:minify', function() {
	gulp.src([])
	.pipe(concat('application.min.css'))
	.pipe(postcss([ autoprefixer({ browsers: ['last 2 versions'], cascade: false }), cssclean() ]))
	.pipe(gulp.dest(paths.dist + "/public/css/build"));

	return gulp.src('app/public/css/dialog.css')
		.pipe(concat('dialog.min.css'))
		.pipe(postcss([ autoprefixer({ browsers: ['last 2 versions'], cascade: false }), cssclean() ]))
		.pipe(gulp.dest(paths.dist + "/public/css/build"));
});


// CSS tasks
gulp.task('css', gulp.series('css:minify'));


// 3.2 JS TASKS

// Transpile javascript to ES5
gulp.task('js:transpile', _ => {
	return gulp.src([''])
		.pipe(babel({ presets: ['es2015']}))
		.pipe(gulp.dest(paths.dist + "/public/js", { overwrite: true }));
});

// Minify and concat javascript
gulp.task('js:minify', _ => {
	gulp.src([])
	.pipe(concat('application.min.js'))
	.pipe(minJs())
	.pipe(gulp.dest(paths.dist + "/public/js/build"));

	return gulp.src()
		.pipe(concat('dialog.min.js'))
		.pipe(minJs())
		.pipe(gulp.dest(paths.dist + "/public/js/build"));

});

// Javascript tasks
gulp.task('js', gulp.series('js:transpile', 'js:minify' ));

/*gulp.task('js:closure', function() {
	return gulp.src([
		'app/public/js/dialog.js',
		'app/public/js/main.js',
	])
	.pipe(compiler({
		compilationLevel: 'ADVANCED',
		warningLevel: 'DEFAULT',
		//outputWrapper: '(function(){\n%output%\n}).call(this)',
		//jsOutputFile: 'dialog.js',
		languageOut: 'ES5',
		createSourceMap: true,
	}))
	.pipe(gulp.dest(paths.dist + "/public/js/build"));
});*/


// 3.3 IMAGE TASKS

// Image tasks
gulp.task('images:minify', _ => {
	return gulp.src(paths.app + "/**")
		.pipe(imagemin())
		.pipe(gulp.dest(paths.dist));
});

gulp.task('images', gulp.series('images:minify'));


// 3.4 HTML TASKS

// Replace js and css with compiled ones
gulp.task('html:replace', function() {
	gulp.src(['app/app/views/layouts/application.php', 'app/app/views/layouts/admin.php', 'app/app/views/layouts/authenticated.php'])
		.pipe(replace({
			'css': '/css/build/application.min.css',
			'js': '/js/build/application.min.js'
		}))
		.pipe(gulp.dest(paths.dist + "/app/views/layouts", { overwrite: true }));

	return gulp.src('app/app/views/layouts/dialog.php')
		.pipe(replace({
			'css': '/css/build/dialog.min.css',
			'js': '/js/build/dialog.min.js'
		}))
		.pipe(gulp.dest(paths.dist + "/app/views/layouts", { overwrite: true }));
});

// Add revisioning information to static files (JS and CSS)
gulp.task('html:revisioning', () => {
  return gulp.src([paths.dist+'/public/css/build/*.css', paths.dist+'/public/js/build/*.js'], { base: paths.dist+'/public' })
    .pipe(rev())
    .pipe(gulp.dest(paths.dist+'/public', { overwrite: true }))
    .pipe(rev.manifest())
    .pipe(gulp.dest(paths.dist));
});

// Replace layout files with revisioned static files (JS and CSS)
gulp.task('html:revisioning-replace', () => {
  var manifest = gulp.src(paths.dist + "/rev-manifest.json");
  return gulp.src(paths.dist + "/app/views/layouts/*.php")
    .pipe(revReplace({manifest: manifest, replaceInExtensions: ['.php'] }))
    .pipe(gulp.dest(paths.dist + "/app/views/layouts", { overwrite: true }));
});

// HTML tasks
gulp.task('html', gulp.series('html:replace', 'html:revisioning', 'html:revisioning-replace'));


// 3.5 FTP tasks
gulp.task('upload', function () {
	var conn = ftp.create({
		host: process.env.FTP_HOST,
		user: process.env.FTP_USER,
		password: process.env.FTP_PASS,
		parallel: 3,
		log: gutil.log,
		idleTimeout: 1000
	} );

	var globs = ['**']

	return gulp.src( globs, { cwd: 'dist', base: 'dist', buffer: false } )
		.pipe(conn.newerOrDifferentSize(  '/ltfawg/public_html/wp-content/themes/news-faking-fluency' ) ) // only upload newer files
		.pipe(conn.dest( '/ltfawg/public_html/wp-content/themes/news-faking-fluency' ) );
});


// 4 - DEFAULT TASKS

//gulp.task('build', gulp.series('copy:app', 'js', 'css', 'images', 'html'));
gulp.task('build', gulp.series('copy:app', 'images'));

// Main task

gulp.task('deploy', gulp.series('build', 'upload'));