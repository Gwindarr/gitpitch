# Learn Thai From a White Guy - WORDPRESS SITE

## How do deploy

- `npm install`
- `npm run deploy`

## How run local dev copy

- `npm run dev`


## dependencies
