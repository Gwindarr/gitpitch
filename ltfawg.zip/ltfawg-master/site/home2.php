<?php require_once ('wp-config.php');
require_once("wp-content/plugins/membermouse/includes/mm-constants.php");
require_once("wp-content/plugins/membermouse/includes/init.php"); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
		
		
		
		<html xmlns="http://www.w3.org/1999/xhtml" prefix="og: http://ogp.me/ns#"><script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><script>var urchinTracker=function(){},_gaq={push:function(){try {if(arguments[0][0]=='_link')window.location.href=arguments[0][1]}catch(er){}}},_gat={_createTracker:function(){}, _getTracker:function(){return{__noSuchMethod__:function(){},_link:function(o){if(o)location.href=o;},_linkByPost:function(){return true;},_getLinkerUrl:function(o){return o;},_trackEvent:function(){}}}};</script><head><script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><script>var urchinTracker=function(){},_gaq={push:function(){try {if(arguments[0][0]=='_link')window.location.href=arguments[0][1]}catch(er){}}},_gat={_createTracker:function(){}, _getTracker:function(){return{__noSuchMethod__:function(){},_link:function(o){if(o)location.href=o;},_linkByPost:function(){return true;},_getLinkerUrl:function(o){return o;},_trackEvent:function(){}}}};</script>
  <meta name="generator" content="HTML Tidy for Linux/x86 (vers 25 March 2009), see www.w3.org">
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii">

  <title>Learn Thai From A White Guy</title>
  <link rel="Shortcut Icon" href="http://learnthaifromawhiteguy.com/wp-content/uploads/2012/08/favicon.ico" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- This site is optimized with the Yoast WordPress SEO plugin v1.4.13 - http://yoast.com/wordpress/seo/ -->
  <link rel="canonical" href="http://learnthaifromawhiteguy.com/">
  <style type="text/css"></style><meta property="og:locale" content="en_US">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com/">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="fb:admins" content="689928716"><!-- / Yoast WordPress SEO plugin. -->
  <link rel="alternate" type="application/rss+xml" title="Learn Thai From A White Guy ? Feed" href="http://learnthaifromawhiteguy.com/feed/">
 
  <link rel="stylesheet" id="slc-css-css" href="http://learnthaifromawhiteguy.com/wp-content/plugins/site-layout-customizer/style.css?ver=1.0.0" type="text/css" media="all">
  <link rel="stylesheet" id="news-theme-css" href="http://learnthaifromawhiteguy.com/wp-content/themes/news/style.css?ver=2.0.0" type="text/css" media="all">
  <script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><style type="text/css"></style><script type="text/javascript" src="http://learnthaifromawhiteguy.com/wp-includes/js/jquery/jquery.js?ver=1.10.2">
</script><style type="text/css"></style><style type="text/css"></style>
  <script type="text/javascript" src="http://learnthaifromawhiteguy.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1">
</script>
 
  <script type="text/javascript" src="http://learnthaifromawhiteguy.com/wp-content/plugins/google-analyticator/external-tracking.min.js?ver=6.4.5">
</script>

  <!-- Open Graph Meta Data by WP-Open-Graph plugin-->
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="og:locale" content="en_us">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com">
  <meta property="og:description" content="Yes, Really">
  <meta property="fb:admins" content="689928716"><!-- /Open Graph Meta Data -->
  <link rel="Shortcut Icon" href="http://learnthaifromawhiteguy.com/wp-content/themes/news/images/favicon.ico" type="image/x-icon">
  <link rel="pingback" href="http://learnthaifromawhiteguy.com/xmlrpc.php">
  <meta name="google-site-verification" content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw">
  <!-- WordPress Facebook Open Graph protocol plugin (WPFBOGP v2.0.7) http://rynoweb.com/wordpress-plugins/ -->
  <meta property="fb:admins" content="689928716">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="og:description" content="">
  <meta property="og:type" content="website">
  <meta property="og:image" content="http://learnthaifromawhiteguy.com/wp-content/uploads/2011/03/all-consonants-150x150.png">
  <meta property="og:locale" content="en_us">

  <script type="text/javascript">
//<![CDATA[
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-16669378-1']);
        _gaq.push(['_addDevId', 'i9k95']); // Google Analyticator App ID with Google 
        
        _gaq.push(['_setCampSourceKey', 'utm_source']);
  _gaq.push(['_setCampMediumKey', 'utm_medium']);
  _gaq.push(['_setCampContentKey', 'utm_content']);
  _gaq.push(['_setCampTermKey', 'utm_keyword']);
  _gaq.push(['_setCampNameKey', 'utm_campaign']);
        _gaq.push(['_trackPageview']);

        (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
  //]]>
  </script>
  <meta name="Description" content="The Best Thai Course on the web!">
  <link href="http://fonts.googleapis.com/css?family=Sniglet" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="/google-tts.min.js">
</script>


<!-- Start Visual Website Optimizer Code -->
<script type="text/javascript">
var _vis_opt_account_id = 60442;
var _vis_opt_protocol = (('https:' == document.location.protocol) ? 'https://' : 'http://');
document.write('<s' + 'cript src="' + _vis_opt_protocol + 
'dev.visualwebsiteoptimizer.com/deploy/js_visitor_settings.php?v=1&a='+_vis_opt_account_id+'&url='
+encodeURIComponent(document.URL)+'&random='+Math.random()+'" type="text/javascript">' + '<\/s' + 'cript>');
</script><script src="http://dev.visualwebsiteoptimizer.com/deploy/js_visitor_settings.php?v=1&amp;a=60442&amp;url=http%3A%2F%2Flearnthaifromawhiteguy.com%2Fhome2.php&amp;random=0.06083955359645188" type="text/javascript"></script><script src="http://dev.visualwebsiteoptimizer.com/deploy/js_visitor_settings.php?v=1&amp;a=60442&amp;url=http%3A%2F%2Flearnthaifromawhiteguy.com%2Fhome2.php&amp;random=0.31397308758459985" type="text/javascript"></script>

<script type="text/javascript">
if(typeof(_vis_opt_settings_loaded) == "boolean") { document.write('<s' + 'cript src="' + _vis_opt_protocol + 
'd5phz18u4wuww.cloudfront.net/vis_opt.js" type="text/javascript">' + '<\/s' + 'cript>'); }
// if your site already has jQuery 1.4.2, replace vis_opt.js with vis_opt_no_jquery.js above
</script>

<script type="text/javascript">
if(typeof(_vis_opt_settings_loaded) == "boolean" && typeof(_vis_opt_top_initialize) == "function") {
        _vis_opt_top_initialize(); vwo_$(document).ready(function() { _vis_opt_bottom_initialize(); });
}
</script>
<!-- End Visual Website Optimizer Code -->



<body class="home blog custom-header content-sidebar news frontpage" style="">
  <div id="wrap">


    <div id="header">
      <div class="wrap">
        <div id="title-area">
          <h1 id="title"><a href="http://learnthaifromawhiteguy.com" title="Learn Thai from a White Guy"><img title="Learn Thai from a White Guy" src="/wp-content/themes/news/images/header.png"></a></h1>

          <div class="head-right">
            <a href="/login">Log In</a>

            <h2>The Best Thai Course on the Web!</h2>
          </div>
        </div>
      </div>
    </div>

    <div id="nav">
		<div class="menu-primary-navigation-container"><ul id="menu-primary-navigation" class="menu"><li id="menu-item-1385" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1385"><a href="http://learnthaifromawhiteguy.com/">Home</a></li>
<li id="menu-item-2717" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2717"><a href="http://learnthaifromawhiteguy.com/start-learning-thai-today/">Web Course</a></li>
<li id="menu-item-3076" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3076"><a href="https://itunes.apple.com/us/app/learn-thai-from-a-white-guy/id673908912?mt=8">iOS App (Free!)</a></li>
<li id="menu-item-3077" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3077"><a href="http://www.youtube.com/user/Gwindarr?feature=watch">LTfaWG: Thai Videos</a></li>
</ul></div>     </div>

    <div id="inner" class="nobg">
      <div class="wrap">
        <div id="content-sidebar-wrap">
  <div class="header-copy">
	<h2>My new online course will get you speaking and reading Thai in just two weeks. <audio id="จริงๆ" src="/speech/จริงๆ.mp3" preload="auto"></audio><a onclick="document.getElementById('จริงๆ').play()" class="speech">จริงๆ</a><span style="font-size: 14px;">*</span></h2>
	
	<p class="smtxt">
		* that means "really"
	</p>
  </div>
				
				<div class="front-topblock cf">
				

  
  
  
  <div class="front-secondblock cf">
  <div class="intro-copy leftblock">
  <h3>Hi, I'm Brett the White Guy.</h3>
  <a href="http://learnthaifromawhiteguy.com/about/"><img src="/wp-content/themes/news/images/whiteguy.png"></a>
  <p class="redpara">Learning languages is my thing but I really struggled with Thai in the beginning.</p>
  <p class="redpara"><strong>Nobody understood me</strong> no matter how hard I tried to get the tones and pronunciation right.</p>
	
	<p>Now I've developed to help you learn Thai. It worked for me and it's worked for hundreds of my students, so I know it will work for you.</p>
	
  </div><div class="tryfree rightblock cf">
                      

                      <h3><a title="Learn Thai from a White Guy Web Course" href="http://learnthaifromawhiteguy.com/start-learning-thai-today/">Try My Course Free</a><br></h3>

                      <a href="http://learnthaifromawhiteguy.com/first-lessons/"><img src="/wp-content/themes/news/images/lessonpack1.jpg"></a>
  <p>Get the first lesson of my web course and you'll see why it works.</p>
  <p>No magic or ancient ninja tricks here, just my tried and true method.</p>

                      

                      

                      

                      <p class="morelink"><a href="http://learnthaifromawhiteguy.com/first-lessons/">Try it Free!</a></p>
                    </div>
  
  </div>
	
</div>
				
				
					
						
				
				
          
            <div class="front-secondblock cf">

                
                    

                    <div class="block-left cf">
                    
<div class="block-inner cf">
                      

                      <h2><a title="Learn Thai from a White Guy Web Course" href="http://learnthaifromawhiteguy.com/start-learning-thai-today/">My Web Course</a><br></h2>

                      <a href="http://learnthaifromawhiteguy.com/start-learning-thai-today/"><img src="/wp-content/themes/news/images/lessonpack1.jpg" style="float: left;"></a>

                      

                      

                      <p>This course is the culmination of ten years learning, speaking and teaching Thai.</p>
<p>By the end of it, you will be able to pronounce everything correctly and Thai people will actually understand you.</p>
<p>You'll also be a master of the alphabet, which means you can read anything you encounter</p>

                      <p class="morelink"><a class="bluebutton" href="learnthaifromawhiteguy.com/start-learning-thai-today/">Learn More</a></p>
                    </div>
</div>

                    <div class="block-right cf">
  <div class="block-inner">
                    

                      

                      <h2><a title="More About Me" href="http://learnthaifromawhiteguy.com/about/">More About Me</a><br></h2>

                      

                      <p>I really like learning languages, but when I first came to Thailand I really struggled to learn Thai. It seemed like nobody could understand me no matter how hard I tried. I realized long ago that the standard methods for teaching a language are pretty darn awful, so I devised a system to teach myself. My goal is to help you avoid making the same mistakes I did and save time, money and your sanity.</p>

                      <p class="morelink"><a class="bluebutton" href="http://learnthaifromawhiteguy.com/about/">Learn More</a></p>
                    </div>
</div>

            </div>
						
						<div class="front-thirdblock cf">
<div class="fb-block">
<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FLearn-Thai-from-a-White-Guy%2F130631900343961&amp;width=260&amp;height=258&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;show_border=true&amp;header=false&amp;appId=325792184119254" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:260px; height:258px;" allowTransparency="true"></iframe>
</div>
						<div class="categories-front">
<div class="sidebar"> 
<?php front_do_sidebar(); ?> 
</div>
      </div>
			</div>
    </div>

    <div id="footer" class="footer">
      <div class="wrap">
        <div class="gototop">
          <p><a href="#wrap" rel="nofollow">Return to top of page</a></p>
        </div>

        <div class="creds">
          <p>Copyright 2016 Learn Thai From A White Guy</p>
        </div>
      </div>
    </div>
  </div>
</body></html>
		