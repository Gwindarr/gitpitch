<?php require_once ('wp-config.php'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" prefix="og: http://ogp.me/ns#">
<?php $isfront = TRUE; ?>
<?php front_change_genesis_sidebar(); ?>
  <meta name="generator" content="HTML Tidy for Linux/x86 (vers 25 March 2009), see www.w3.org">
  <meta http-equiv="Content-Type" content="text/html; charset=us-ascii">

  <title>Learn Thai From A White Guy -</title>
  <link rel="Shortcut Icon" href="http://learnthaifromawhiteguy.com/wp-content/uploads/2012/08/favicon.ico" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- This site is optimized with the Yoast WordPress SEO plugin v1.4.13 - http://yoast.com/wordpress/seo/ -->
  <link rel="canonical" href="http://learnthaifromawhiteguy.com/">
  <style type="text/css"></style><meta property="og:locale" content="en_US">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy -">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com/">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="fb:admins" content="689928716"><!-- / Yoast WordPress SEO plugin. -->
  <link rel="alternate" type="application/rss+xml" title="Learn Thai From A White Guy » Feed" href="http://learnthaifromawhiteguy.com/feed/">
 
  <link rel="stylesheet" id="slc-css-css" href="http://learnthaifromawhiteguy.com/wp-content/plugins/site-layout-customizer/style.css?ver=1.0.0" type="text/css" media="all">
  <link rel="stylesheet" id="news-theme-css" href="http://learnthaifromawhiteguy.com/wp-content/themes/news/style.css?ver=2.0.0" type="text/css" media="all">
  <script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><script type="text/javascript" src="http://learnthaifromawhiteguy.com/wp-includes/js/jquery/jquery.js?ver=1.10.2">
</script><style type="text/css"></style>
  <script type="text/javascript" src="http://learnthaifromawhiteguy.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1">
</script>
 
  <script type="text/javascript" src="http://learnthaifromawhiteguy.com/wp-content/plugins/google-analyticator/external-tracking.min.js?ver=6.4.5">
</script>
  <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://learnthaifromawhiteguy.com/xmlrpc.php?rsd">
  <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://learnthaifromawhiteguy.com/wp-includes/wlwmanifest.xml">

  <!-- Open Graph Meta Data by WP-Open-Graph plugin-->
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="og:locale" content="en_us">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com">
  <meta property="og:description" content="Yes, Really">
  <meta property="fb:admins" content="689928716"><!-- /Open Graph Meta Data -->
  <link rel="Shortcut Icon" href="http://learnthaifromawhiteguy.com/wp-content/themes/news/images/favicon.ico" type="image/x-icon">
  <link rel="pingback" href="http://learnthaifromawhiteguy.com/xmlrpc.php">
  <meta name="google-site-verification" content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw">
  <!-- WordPress Facebook Open Graph protocol plugin (WPFBOGP v2.0.7) http://rynoweb.com/wordpress-plugins/ -->
  <meta property="fb:admins" content="689928716">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="og:description" content="">
  <meta property="og:type" content="website">
  <meta property="og:image" content="http://learnthaifromawhiteguy.com/wp-content/uploads/2011/03/all-consonants-150x150.png">
  <meta property="og:locale" content="en_us">

  <script type="text/javascript">
//<![CDATA[
        var analyticsFileTypes = [''];
        var analyticsEventTracking = 'enabled';
  //]]>
  </script>
  <script type="text/javascript">
//<![CDATA[
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-16669378-1']);
        _gaq.push(['_addDevId', 'i9k95']); // Google Analyticator App ID with Google 
        
        _gaq.push(['_setCampSourceKey', 'utm_source']);
  _gaq.push(['_setCampMediumKey', 'utm_medium']);
  _gaq.push(['_setCampContentKey', 'utm_content']);
  _gaq.push(['_setCampTermKey', 'utm_keyword']);
  _gaq.push(['_setCampNameKey', 'utm_campaign']);
        _gaq.push(['_trackPageview']);

        (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
  //]]>
  </script>
  <meta name="Description" content="The #1 Thai Course on the web! From Zero to Fluent.">
  <link href="http://fonts.googleapis.com/css?family=Sniglet" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="/google-tts.min.js">
</script>
  <script type="text/javascript" src="/wp-content/themes/news/tracking.js">
</script>

</head>

<body class="home blog custom-header content-sidebar news">
  <div id="wrap">


    <div id="header">
      <div class="wrap">
        <div id="title-area">
          <h1 id="title"><a href="http://learnthaifromawhiteguy.com"><img title="Learn Thai from a White Guy" src="/wp-content/themes/news/images/header.png"></a></h1>

          <div class="head-right">
            <a href="/login">Log In</a>

            <h2>The #1 Thai Course on the Web!</h2>
          </div>
        </div>
      </div>
    </div>

    <div id="nav">
		<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ) ?>
     </div>

    <div id="inner" class="nobg">
      <div class="wrap">
        <div id="content-sidebar-wrap">
				
				<div class="front-topblock cf">
  <h1>Learn Thai with my Online Course!</h1>
  <a href="/first-lessons" title="Get your first lesson!">
<img src="/wp-content/themes/news/images/startimg.png">
</a>
  
  <div class="topblock-copy">
  <p class="smallquote">“This makes living in Thailand a blast”</p>
  
  <p class="topblock-top">If you've had it with boring classes and lame textbooks, my web course is for you. I've been teaching foreigners to speak Thai for over seven years and I'm confident that anybody can learn with my methods.</p>
<p class="topblock-bottom">After my first lesson pack, <strong>I guarantee:</strong></p>
	<ul>
	
		<li>You'll be able to pronounce <strong>every</strong> Thai word correctly</li>
		<li>Thai people will actually understand everything you say</li>
		<li>You'll be able to read <strong>any</strong> Thai word you come across and even decode menus and signs</li>
		<li>You can stop getting ripped off and pay the "Thai Price"
	</li></ul>
  </div>
	
</div>
				
				
					
						
				
				
          
            <div class="front-secondblock cf">

                
                    

                    <div class="block-left cf">
                    
<div class="block-inner cf">
                      

                      <h2><a title="Learn Thai from a White Guy Web Course" href="http://learnthaifromawhiteguy.com/start-learning-thai-today/">My
                      Web Course</a><br></h2>

                      <p><a href="http://learnthaifromawhiteguy.com/start-learning-thai-today/"><img src="/wp-content/themes/news/images/lessonpack1.jpg" style="float: left;"></a></p>

                      

                      <p class="smallquote">“I feel so confident holding conversations knowing the
                      language I’m using is the real deal”</p>

                      <p>This course is the culmination of many years of teaching people
                      Thai. I’ve taught total beginners, fluent and partially
                      fluent speakers who can’t read and even Thais and half-Thais
                      who grew up abroad. My system for learning to speak and read works
                      and it works well.</p>

                      <p class="morelink"><a href="http://learnthaifromawhiteguy.com/start-learning-thai-today/">Look
                      Inside</a></p>
                    </div>
</div>

                    <div class="block-right cf">
  <div class="block-inner">
                    

                      

                      <h2><a title="Hi, I’m the White Guy" href="http://learnthaifromawhiteguy.com/about/">Hi, I’m the White
                      Guy</a><br></h2>

                      <p><a href="http://learnthaifromawhiteguy.com/about/"><img src="/wp-content/themes/news/images/whiteguy.png" style="float: right;"></a></p>

                      <p>My name is Brett and I’ve spent the past 10 years trying
                      to learn far too many languages. I had a rough time in the
                      beginning years with Thai because I had no idea what I was doing
                      and I realized long ago that the standard methods for teaching a
                      language are pretty darn awful. My hope with this site is to
                      deliver my methodology for learning Thai and help people save time,
                      money and stress by making the process as painless and as
                      straightforward as possible.</p>

                      <p class="morelink"><a href="http://learnthaifromawhiteguy.com/about/">More About
                      Me</a></p>
                    </div>
</div>

            </div>
<div class="fb-block">
<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FLearn-Thai-from-a-White-Guy%2F130631900343961&amp;width=260&amp;height=258&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;show_border=true&amp;header=false&amp;appId=325792184119254" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:260px; height:258px;" allowTransparency="true"></iframe>
</div>
						<div class="categories-front">
<div class="sidebar"> 
<?php front_do_sidebar(); ?> 
</div>

      </div>
    </div>

    <div id="footer" class="footer">
      <div class="wrap">
        <div class="gototop">
          <p><a href="#wrap" rel="nofollow">Return to top of page</a></p>
        </div>

        <div class="creds">
          <p>Copyright © 2013 Learn Thai From A White Guy</p>
        </div>
      </div>
    </div>
  </div>

 


  </body></html>