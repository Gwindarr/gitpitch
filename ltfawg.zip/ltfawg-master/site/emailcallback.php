<?php
require_once("mixpanel-php/lib/Mixpanel.php");
require_once("universal-analytics.php");
$mp = Mixpanel::getInstance("39419bbad75e3856efc5599fe74b3617");

$grid = $_GET["CONTACT_ID"];
$graction = $_GET["amp;action"];
$gremail = urldecode($_GET["amp;contact_email"]);
$grmessagename = urldecode($_GET["amp;message_name"]);
$grsubject = urldecode($_GET["amp;message_subject"]);
$grclick = urldecode($_GET["amp;link_url"]);

// mixpanel

if ($graction == 'subscribe') {
$mp->people->set($grid, array( '$name' => $gremail, '$email' => $gremail ));
$mp->identify($grid);
$mp->track("optin");
}

if ($graction == 'open') {
$mp->identify($grid);
$mp->track("email open", array( "message" => $grmessagename, "subject" => $grsubject ));
}

if ($graction == 'click') {
$mp->identify($grid);
$mp->track("email click", array( "message" => $grmessagename, "subject" => $grsubject, "link" => $grclick ));
}

// analytics

$t = new Tracker( 'UA-16669378-1', '815835312344-smsfo23t54qg83gg8n269diq376nurcu.apps.googleusercontent.com', null);

if ($graction == 'subscribe') {
	$t->send( 'event', array(
		'eventCategory' => 'conversion',
		'eventAction' => 'optin',
	));
}

if ($graction == 'open') {
	$t->send( 'event', array(
		'eventCategory' => 'email',
		'eventAction' => 'open',
	));
}

if ($graction == 'click') {
	$t->send( 'event', array(
		'eventCategory' => 'email',
		'eventAction' => 'click',
	));
}

/*
$textwrite = print_r($_REQUEST,true);

$file = fopen("callbacks.txt","a");
echo fwrite($file,$grid.' '.$graction.' '.$gremail);
fclose($file);
*/
?>