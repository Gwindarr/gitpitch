<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'dptm777_learnthai');

/** MySQL database username */
define('DB_USER', 'dptm777_learntha');

/** MySQL database password */
define('DB_PASSWORD', 'yqo]V.+BmaP;');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '{0W5<RZ+Nk=es[F>)4tY8/JLygu%)U[TiQV_*B(n|^M=jJf ;dq*WDL~I.5Jz$!(');
define('SECURE_AUTH_KEY',  'hrKQ(1?|z1>)`lK!78];/eVo6g#-;]<C*Dx9#+u2PmOB8TIt`Z.,8.l{ykRm56Y[');
define('LOGGED_IN_KEY',    'Rt+t]{JD]-R>aV2fU;>zT^,a|WjTdDTMbduAI>p^^N?hMiD>u^#h*{wam-.*/k0g');
define('NONCE_KEY',        'I_yBq$==f%-5v9<bU8 mD%~Z)I!:o9+Hn8Z4iB>d8;g+rzWIK_9dDBU!Q8I<}G8{');
define('AUTH_SALT',        '|p-^/{Lk|2{2pR].HrpBWi^TH%Uo;_+ ?5oQ?3;5r;L9t][yj/-2f4?-.,##>rX&');
define('SECURE_AUTH_SALT', '_;zKae_{lJ-OH B*XRQf39^nUGvo^25)<-9$slGEXI(*25Rr&SJ.# 37E=o]8b=?');
define('LOGGED_IN_SALT',   'm6Vn|sKf|bADFgnW9)u<zV6H`)2wh5|g9|Uqexc4vp)&;V,:h[h.ogf1I`M+@R6{');
define('NONCE_SALT',       'B)Pq_K/zF%l10):Y)1$loOfGjfJc(mJYC.AE Ekqi|7p_NWYN!*8++E>|7dX5h`O');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
