<?php 
// This file demonstrates how to handle different payment events and access the data passed to the script by MemberMouse.

// ---- GET EVENT TYPE ----
if(!isset($_GET["event_type"])) 
{
	// event type was not found, so exit
	exit;
}
else 
{
	$eventType = $_GET["event_type"];
}


// ---- ACCESS DATA ----
// member data
$memberId = $_GET["member_id"];
$registeredDate = $_GET["registered"];
$lastLoginDate = $_GET["last_logged_in"];
$lastUpdatedDate = $_GET["last_updated"];
$daysAsMember = $_GET["days_as_member"];
$status = $_GET["status"];
$statusName = $_GET["status_name"];
$membershipLevelId = $_GET["membership_level"];
$membershipLevelName = $_GET["membership_level_name"];
$isComplimentary = $_GET["is_complimentary"];
$username = $_GET["username"];
$email = $_GET["email"];
$phone = $_GET["phone"];
$firstName = $_GET["first_name"];
$lastName = $_GET["last_name"];
$billingAddress = $_GET["billing_address"];
$billingCity = $_GET["billing_city"];
$billingState = $_GET["billing_state"];
$billingZipCode = $_GET["billing_zip_code"];
$billingCountry = $_GET["billing_country"];
$shippingAddress = $_GET["shipping_address"];
$shippingCity = $_GET["shipping_city"];
$shippingState = $_GET["shipping_state"];
$shippingZipCode = $_GET["shipping_zip_code"];
$shippingCountry = $_GET["shipping_country"];

// custom field data
// You can access custom field data by accessing the get parameter cf_# where # is the
// ID of the custom field
//$exampleCustomData = $_GET["cf_1"];

// order data
$orderNumber = $_GET["order_number"];
$orderTransactionId = $_GET["order_transaction_id"];
$orderTotal = $_GET["order_total"];
$orderSubtotal = $_GET["order_subtotal"];
$orderDiscount = $_GET["order_discount"];
$orderIPAddress = $_GET["order_ip_address"];

// access products associated with the order
$products = json_decode(stripslashes($_GET["order_products"]));

foreach($products as $product)
{
	$productId = $product->id;
	$productName = $product->name;
	$productSku = $product->sku;
	$productAmount = $product->amount;
	$productQuantity = $product->quantity;
	$productTotal = $product->total;						// amount * quantity
	$productIsRecurring = $product->is_recurring;			// true, false
	$productRecurringAmount = $product->recurring_amount;	// amount charged every rebill period
	$productRebillPeriod = $product->rebill_period;			// integer - complete rebill period is a combination of rebill period 
															// and frequency i.e. 1 months, 30 days, 2 weeks, etc.
	$productRebillFrequency = $product->rebill_frequency;  	// days, weeks, months, years
}

// access coupons associated with the order
$coupons = json_decode(stripslashes($_GET["order_coupons"]));
foreach($coupons as $coupon)
{
	$couponId = $coupon->id;	
	$couponName = $coupon->name;
	$couponCode = $coupon->code;
}


// ---- EVENT TYPES ----
$PAYMENT_RECEIVED = "mm_payment_received";
$PAYMENT_REBILL = "mm_payment_rebill";
$PAYMENT_REBILL_FAILED = "mm_payment_rebill_declined";
$REFUND_ISSUED = "mm_refund_issued";




// ---- LOAD ANALYTICS ----
require_once("universal-analytics.php");


// ---- PERFORM ACTION BASED ON EVENT TYPE ----
switch($eventType)
{
	case $PAYMENT_RECEIVED:
		//$t = new Tracker(/* web property id */ 'UA-XXXXX-Y', /* client id */ 'abc', /* user id */ null);
		$t = new Tracker('UA-16669378-1', '815835312344-smsfo23t54qg83gg8n269diq376nurcu.apps.googleusercontent.com', null);
		
		// Send an event
		$t->send(/* hit type */ 'event', /* hit properties */ array(
		  'eventCategory' => 'conversion',
		  'eventAction' => 'sale - payment received',
		  'eventLabel' => $products[0]->name;
		  'evenValue' => $orderTotal;
		));
		
		// Send a transaction
		$t->send('transaction', array(
		  'transactionId' => $orderTransactionId,
		  'transactionRevenue' => $orderTotal // not including tax or shipping
		));
		
		foreach($products as $product)
		{
			// Send an item record related to the preceding transaction
			$t->send('item', array(
			  'transactionId' => $orderTransactionId,
			  'itemName' => $product->name,
			  'itemPrice' => $product->amount,
			  'itemQuantity' => $product->quantity
			));
			
		}
		// do something
		break;
		
	case $PAYMENT_REBILL:
		// do something
		break;
		
	case $PAYMENT_REBILL_FAILED:
		// do something
		break;
		
	case $REFUND_ISSUED:
		// do something
		break;
}
?>




<?php
/*



	require_once("mixpanel-php/lib/Mixpanel.php");
	require_once("universal-analytics.php");

	$mp = Mixpanel::getInstance("39419bbad75e3856efc5599fe74b3617");

	
	$amount=$_POST['amount'];
	$first_name=$_POST['first_name'];
	$last_name=$_POST['last_name'];
	$email=$_POST['email'];
	$member_id=mt_rand(1000,99999);
	$id = $_POST['id'];
	
	if (!$id) {
		$id = $member_id;
	}
	
	if (!empty($amount)) {
	
		$mp->people->set($member_id, array(
			'$first_name'       => $first_name,
			'$last_name'        => $last_name,
			'$email'            => $email,
		));

		$mp->identify($member_id);
		$mp->track('sale', array(
		'amount' => $amount,
		'name' => $first_name,
		'email' => $email,
		));
		
		$mp->track('sale - manual', array(
			'amount' => $amount,
			'name' => $first_name,
			'email' => $email,
		));
		
		$mp->people->trackCharge($member_id, $amount);

		// analytics

		$t = new Tracker( 'UA-16669378-1', '815835312344-smsfo23t54qg83gg8n269diq376nurcu.apps.googleusercontent.com', null);

		$t->send( 'event', array(
			'eventCategory' => 'conversion',
			'eventAction' => 'sale',
			'eventLabel' => 'web course',
			'eventValue' => $amount
		));

		$t->send('transaction', array(
			'transactionId' => $member_id,
			'transactionRevenue' => $amount
		));
		
		echo "tracked, thx";
		}






<p>Manually track a sale in mixpanel and analytics:</p>

<form name="track_sale" id="track_sale" action="track-sale.php" method="POST">
	<p>
		<label for="amount">Amount:</label>
		<br>
		<input type="text" name="amount">
	</p>
	<p>
		<label for="amount">First name:</label>
		<br>
		<input type="text" name="first_name">
	</p>
	<p>
		<label for="amount">Last name:</label>
		<br>
		<input type="text" name="last_name">
	</p>
	<p>
		<label for="amount">Email:</label>
		<br>
		<input type="text" name="email">
	</p>
	<input type="submit" value="do it">
</form>