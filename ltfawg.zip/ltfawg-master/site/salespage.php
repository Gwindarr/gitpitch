<?php
require_once ('wp-load.php');
require_once("wp-content/plugins/membermouse/includes/mm-constants.php");
require_once("wp-content/plugins/membermouse/includes/init.php");

require 'wp-content/themes/news-faking-fluency/_products_config.php';

$product = $products['read-thai-in-2-weeks'];

$title = mm_product_data(array('id' => $product['product_id'], 'name' => 'name'));
$description = mm_product_data(array('id' => $product['product_id'], 'name' => 'description'));
$billing_description = mm_product_data(array('id' => $product['product_id'], 'name' => 'billingDescription'));
$price = mm_product_data(array('id' => $product['product_id'], 'name' => 'price', 'doFormat' => 'false'));

$discount = 147-$price;
?>

<!DOCTYPE html>
<html>
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Learn Thai Online - Learn Thai From A White Guy</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="canonical" href="https://learnthaifromawhiteguy.com/learn-thai-online" />
	<meta property='og:locale' content='en_US'/>
	<meta property='og:type' content='article'/>
	<meta property='og:title' content='Learn Thai From A White Guy'/>
	<meta property='og:description' content="I've spent the last ten years learning Thai and developing this course so
	you won't have to make the same language-learning mistakes I did. I've taught hundreds of students with this method
	and I guarantee you will be able to read, write and prounounce everything correctly after 10 hours of studying."/>
	<meta property='og:url' content='https://learnthaifromawhiteguy.com/learn-thai-online'/>
	<meta property='og:site_name' content='Learn Thai From A White Guy'/>
	<meta property='fb:admins' content='689928716'/>
	<meta property='og:image' content='https://learnthaifromawhiteguy.com/ogimg.png'/>

	<?php include 'wp-content/themes/news-faking-fluency/_analytics.php'; ?>

	<link rel='stylesheet' id='news-theme-css'  href='/wp-content/themes/news-faking-fluency/style.min.css?ver=3.0.1' type='text/css' media='all' />
	<meta name="google-site-verification" content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw" />
	<meta name="Description" content="The Best Thai Course on the web!">
	<link href='https://fonts.googleapis.com/css?family=Sniglet' rel='stylesheet' type='text/css'>

	<link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96">
	<link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
	<link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">

	<!-- Android/Chrome -->
	<link rel="manifest" href="manifest.json">
	<meta name="theme-color" content="#FFF">
	<link rel="icon" type="image/png" href="/favicon-192x192.png" sizes="192x192">
	<link rel="apple-icon" sizes="57x57" href="/apple-icon-57x57.png">
	<link rel="apple-icon" sizes="114x114" href="/apple-icon-114x114.png">
	<link rel="apple-icon" sizes="72x72" href="/apple-icon-72x72.png">
	<link rel="apple-icon" sizes="144x144" href="/apple-icon-144x144.png">
	<link rel="apple-icon" sizes="60x60" href="/apple-icon-60x60.png">
	<link rel="apple-icon" sizes="120x120" href="/apple-icon-120x120.png">
	<link rel="apple-icon" sizes="76x76" href="/apple-icon-76x76.png">
	<link rel="apple-icon" sizes="152x152" href="/apple-icon-152x152.png">
	<link rel="apple-icon" sizes="180x180" href="/apple-icon-180x180.png">


	<meta name="msapplication-TileColor" content="#FFF">
	<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
</head>
<body class="page page-id-2729 page-template page-template-salespage-test-php page-template-salespage-php custom-header content-sidebar">

	<div id="wrap">
		<div id="header">
			<div class="wrap">
				<div id="title-area">
					<a href="https://learnthaifromawhiteguy.com">
						<img title="Learn Thai from a White Guy" src="/wp-content/themes/news-faking-fluency/images/header.png">
					</a>
					<div class="head-right">
						<div class="subtitle wrap">
							<h2>The Best Thai Course on the Web</h2>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="inner">
			<div class="wrap">

			<div id="content" class="hfeed">

				<div class="entry-content sales-content">
					<h1 class="sales-title">Learn Thai Online!</h1>
					<div class="textblock struggle cf">
						<a href="<?=$product['checkout_url']?>">
							<img src="/wp-content/themes/news-faking-fluency/images/products/read_thai_in_2_weeks.jpg"
								style="max-width: 40%; margin-right: 2em">
						</a>
						<p class="size3"><strong>My first Thai course</strong> has everything you need to read and start
						speaking Thai. No boring fake dialogues or useless kids' books here - I'm just going to tell you
						exactly what you need to know and how to practice it.  I've been perfecting my method for over
						10 years and thousands have used it. I know it works and I know it'll work for you.
						Can you spare 2 weeks?*</p>

						<p class="size3" style="font-style:italic">*My course should take you about 2 weeks to complete
						if you follow the program and study about 30-40 minutes each day.  Individual results may vary,
						but 2 weeks should be your goal line and you can email me anytime if you get stuck. You'll need
						to review the material everyday, but when you finish you'll be able to do all of the following
						stuff:</p>
					</div>

					<div class="sales-blocks blocks-first">
						<div class="sales-block block-1">
							<h4>Know How to Pronounce Everything Correctly!</h4>
							<img src="/wp-content/themes/news-faking-fluency/images/sounds.jpg">
							<p>Puzzled by prounciation? Terrible with tones? Once you are a few hours into my course, it
							will all become clear</p>
						</div>

						<div class="sales-block block-2">
							<h4>Thai People will Actually Understand You!</h4>
							<img src="/wp-content/themes/news-faking-fluency/images/people.jpg">
							<p>Do Thai people ever struggle to understand what you are saying?  It's time to fix that.</p>
						</div>

						<div class="sales-block block-3">
							<h4>You'll Be Able to Read Signs and Menus!</h4>
							<img src="/wp-content/themes/news-faking-fluency/images/signs.jpg">
							<p>You won't be able to understand a novel or newspaper yet, but after my course you'll be
							able to work through menus and signs with ease.</p>
						</div>
					</div>

					<div style="text-align: center; margin-bottom: 2em;" class="addtocart">
						<p>Buy Now and Get <span class="discount">$<?=$discount?> off!</span></p>
						<p class="prices">
							<div style="display: inline-block; color: red; font-size: 40px; font-weight: bold; text-decoration:line-through; margin-right: .5em; padding: 1em .5em">
								$147
							</div>
							<div style="display: inline-block; color: red; font-size: 40px; margin-left: .5em; font-weight: bold; padding: 1em .5em; border: 3px solid red; border-radius:50px">
								$<?=round($price)?>
							</div>
						</p>
						<a href="<?=$product['checkout_url']?>">
							<img src="/wp-content/themes/news-faking-fluency/images/buynow.jpg" style="float: none;">
						</a>
					</div>

					<div class="floatquote cf">
						<p>"Brett's ability to unravel the mystery has really opened up a lot of doors for me"</p>
						<p class="attrib">- Matt from the UK</p>
					</div>

					<div class="testimonial cf">
						<div class="youtubeclip">
							<iframe width="480" height="294" src="//www.youtube.com/embed/r__W_2BvvRs" frameborder="0"
								allowfullscreen=""></iframe>
						</div>
						<p>"I will admit that I was skeptical about your course for many reasons, and EVERY SINGLE doubt
						 I had before purchasing was silly and pointless, and I knew this by about the second day of
						 studying, because <strong>my wife is a native Thai speaker and she couldn't contain her
						 surprise</strong> at how successful my accent and proficiency became after I began using
						 your course."*</p>
						<p class="attrib">- Mike Oppenheim</p>

						<p style="clear:both; padding-top:1em; font-size:0.9em"><i>*Disclaimer: Mike learned to read
						Thai in about 2 weeks using an older ebook version of my course.  The time it takes you to learn
						to read may vary from Mike's experience, but if you spend at least 30 minutes a day on the
						course, you shouldn't have any problem finishing it within about 2 weeks.</i></p>
					</div>

					<div class="textblock bounced cf">
						<img class="alignright salesimg1" width="120" height="207"
							src="/wp-content/themes/news-faking-fluency/images/whiteguy.png"
								alt="" title="Start Learning Thai Today!">
						<h3>Hi, I'm Brett the White Guy.</h3>
						<p>
							Have you struggled with boring Thai books and lessons and <em>still</em> can't talk to
							anybody or understand anything? Have you been frustrated by the fact that no one can just
							explain stuff simply? Are you still waiting for it to 'click' so you can start having real
							conversations in Thai? I've been there. I'm a foreigner who went all the way from zero to
							fluent and I want to show you how I did it. I'll also steer you away from the loads of
							time-wasting, frustrating mistakes that almost everybody makes. I've already struggled
							through them and I want to make sure my students don't have to.
						</p>
					</div>

					<h2>Learn to Read Thai in 2 Weeks</h2>
					<h5>Here's What You Get:</h5>

					<div class="sales-blocks blocks-second">
						<div class="sales-block block-1">
							<h4>Over 50 Comprehensive Lessons</h4>
							<img src="/wp-content/themes/news-faking-fluency/images/39lessons.png">
							<p>My course covers everything you need to know to read Thai.  This includes everything
							u need to know about the Thai script, sound system as well as how to understand and master
							he Thai tone rules.  There are in-course flashcards in the lessons to help you practice and
							you an email me for help at any time if you have questions.  </p>
						</div>

						<div class="sales-block block-2">
							<h4>Clickable Audio</h4>
							<div class="audio-row">
								<a class="speech audio_link wdb-thai-word wdb-word wdb-ranking-0" data-word="ก"
									data-id="audio-2143" style="display: inline-block">ก
									<audio id="audio-2143" src="/audio/audio-2143.mp3" preload="auto"></audio>
								</a>&nbsp;&nbsp;
								<a class="speech audio_link wdb-thai-word wdb-word wdb-ranking-0" data-word="ม"
									data-id="audio-432" style="display: inline-block">ม
									<audio id="audio-432" src="/audio/audio-432.mp3" preload="auto"></audio>
								</a>&nbsp;&nbsp;
								<a class="speech audio_link wdb-thai-word wdb-word wdb-ranking-0" data-word="ด"
									data-id="audio-379" style="display: inline-block">ด
									<audio id="audio-379" src="/audio/audio-379.mp3" preload="auto"></audio>
								</a>&nbsp;&nbsp;
								<p>(click each letter)</p>
							</div>
							<p>Everything single Thai letter or word in my web course has clickable audio recorded by a
							professional voice artist.  Part of learning a language is listening over and over again and
							you'll be wanting to click on those words a lot!</p>
						</div>

						<div class="sales-block block-3">
							<h4>600+ Digital Flash Cards</h4>
							<img src="/wp-content/themes/news-faking-fluency/images/anki.jpg">
							<p>I made a special set of flash cards specifically for this course, complete with audio
							for every one. The flash cards work with <a href="http://ankisrs.net" target="_blank">Anki</a>
							software, so the deck will intelligently pick which cards you need to review and will sync
							your progress to your phone, tablet or other computers.</p>
						</div>
					</div>

					<div class="testimonial cf">
						<div class="youtubeclip">
							<iframe width="480" height="294" src="//www.youtube.com/embed/ITX1aN2_YIg"
								frameborder="0"></iframe>
						</div>
						<p>"Within just a month I had the alphabet and the tone rules down and I was starting to sound
						out words and sentences. <strong>I was really only studying for 15 or 20 minutes a day*</strong>.
						Brett really breaks down the language so you're able to learn pieces at a time without getting
						overwhelmed."</p>
						<p class="attrib">- Maren</p>
						<p style="clear:both; padding-top:1em; font-size:0.9em"><i>*Disclaimer: While Maren mastered the
						script in a month, your results may vary based on your own study habits and time spent. If you
						follow the course as laid out with daily study of at least 30 minutes, you can expect to complete
						it in approximately 2 weeks..</i>
						</p>
					</div>

					<!--div class="testimonial cf">
						<img src="/wp-content/themes/news-faking-fluency/images/quote-john.jpg">
						"<b>In 3 hours, I'd pummeled the thai alphabet into my head</b>. All those squiggly lines and
						curly characters? I know 'em. It's been a smooth ride ever since. 3 months down the road and I
						can read pretty much everything (and understand a helluva lot more of what's going on round me).
						This makes living in Thailand a blast. Also, when I hear other foreigners speaking Thai who
						haven't learned the alphabet, they sound ridiculous and nothing like the way they should sound."
						<p class="attrib">- John from Australia</p>
						</div>
					</div>-->

					<div class="testimonial cf">
						<div class="youtubeclip">
							<iframe width="480" height="294" src="https://www.youtube.com/embed/-yhT3p-yWNk"
								frameborder="0"></iframe>
						</div>
						<p>"I can now read and write short words in Thai and have a full understanding of the tones"</p>
						<p class="attrib">- <b>Vince</b>, New Zealand </p>
					</div>
				</div>

				<div class="testimonial cf">
					<img src="/wp-content/themes/news-faking-fluency/images/quote-travis.jpg">
					"<b>I'm blown away by the progress I've made</b>. I can read anything in Thai, understand the tone
					and properly pronounce it. After learning how to read, he started teaching me practical vocabulary,
					sentence structure and how to speak like a Thai (which is way different than hat most language books
					will teach you, of course). I live in Thailand and my experience here has drastically improved since
					studying with Brett. I've been sending fellow expats his way ever since my first lesson - this guy
					knows what he's doing."
					<p class="attrib">- Travis from USA</p>
				</div>

				<div class="testimonial cf">
					<img src="/wp-content/themes/news-faking-fluency/images/quote-matt.jpg">
					"Been studying with the white guy for almost a year now, that should tell its own story. <b>You
					really do get the alphabet cracked in a matter of hours!!</b> Brett's ability to unravel the mystery
					has really opened up a lot of doors for me. Every lesson I'm learning new material, on stuff I want
					to learn about. I feel so confident holding conversations knowing the language I'm using is the real
					deal!! No more over-polite robot speech!! This confidence combined with a no-pressure learning
					environment is what keeps me coming back for more!!"
					<p class="attrib">- Matt from UK</p>
				</div>

				<div class="textblock beforebuy">
					<p>My first web course has over 50 lessons for <b>only $<?php echo $price; ?></b>. Like I said, it
					should take you about 2 weeks* to get through all the material in the course, but you'll have
					<b>lifetime access</b> so you can take as long as you'd like. You'll also have unlimited email
					support while using the course so you can email me whenever you have questions.</p>
				</div>

				<small><p><i>*Results may vary based on the time you spend studying each day.  It is certainly possible
				to complete it in less time, and if you somehow find yourself in the 3rd week and you still haven't
				completed the course, just email me and I'll help you get back on track.</i></p></small>

				<div class="testimonial cf">
					<img src="/wp-content/themes/news-faking-fluency/images/guarantee.png">When you get my web course, you get a 100%
					money-back guarantee. That means that you can learn how to read, write, say everything correctly and
					communicate more effectively. But if you are dissatisfied with the course for any reason whatsoever,
					just let me know within 30 days I'll give you a full refund no questions asked.
				</div>

				<div style="text-align: center; margin-bottom: 2em;" class="addtocart">
					<p>Buy Now and Get <span class="discount">$<?=$discount?> off!</span></p>
					<p class="prices">
						<div style="display: inline-block; color: red; font-size: 40px; font-weight: bold; text-decoration:line-through; margin-right: .5em; padding: 1em .5em">
							$147
						</div>
						<div style="display: inline-block; color: red; font-size: 40px; margin-left: .5em; font-weight: bold; padding: 1em .5em; border: 3px solid red; border-radius:50px">
							$<?=round($price)?>
						</div>
					</p>
					<a href="<?=$product['checkout_url']?>">
						<img src="/wp-content/themes/news-faking-fluency/images/buynow.jpg" style="float: none;">
					</a>
				</div>
			</div>
		</div><!-- end #content -->
	</div>
	<div id="sidebar" class="sidebar widget-area"></div>
	</div>
</div>
	<div id="footer" class="footer">
			<div class="wrap">
				<div class="gototop">
					<p><a href="#wrap" rel="nofollow">Return to top of page</a></p>
			</div>
			<div class="creds"><p>Copyright &#x000A9; 2017 Learn Thai From A White Guy</p></div>
		</div>
	</div>
	</div>
	<script>
		var elems = document.querySelectorAll('a.speech');
		var i;

		for (i = 0; i < elems.length; ++i) {
			var e = elems[i];
			e.addEventListener('click', function() {
				var audio_id = this.getAttribute('data-id');
				document.getElementById(audio_id).play();
			});
		}
	</script>
</body>
</html>
