<?php

require_once("universal-analytics.php");
#require_once("mixpanel-php/lib/Mixpanel.php");
#$mp = Mixpanel::getInstance("39419bbad75e3856efc5599fe74b3617");
	
$amount         = $_POST['amount'];
$product        = $_POST['product'];
$email          = $_POST['email'];
$transaction_id = $_POST['transaction_id'];
	
	/*$mp->people->set($member_id, array(
    '$first_name'       => $first_name,
   '$last_name'        => $last_name,
		'$email'            => $email,
));

$mp->identify($member_id);
$mp->track('manual sale', array(
'amount' => $amount,
'name' => $first_name,
'email' => $email,
));
	
$mp->people->trackCharge($member_id, $amount);*/

// analytics

if ($amount) {
	$t = new Tracker('UA-16669378-1', '815835312344-smsfo23t54qg83gg8n269diq376nurcu.apps.googleusercontent.com', null);

	// Send an event
	$t->send(/* hit type */ 'event', /* hit properties */ array(
		'eventCategory' => 'conversion',
		'eventAction' => 'manual sale - payment received',
		'eventLabel' => $product,
		'evenValue' => $amount
	));

	// Send a transaction
	$t->send('transaction', array(
		'transactionId' => $transaction_id,
		'transactionRevenue' => $amount // not including tax or shipping
	));

	// Send an item record related to the preceding transaction
	$t->send('item', array(
		'transactionId' => $transaction_id,
		'itemName' => $product,
		'itemPrice' => $amount,
		'itemQuantity' => 1
	));
}
	
?>


<p>Manually track a sale in analytics:</p>

<form name="track_sale" id="track_sale" action="track-sale-form.php" method="POST">
	<p>
		<label for="amount">Amount:</label>
		<br>
		<input type="text" name="amount">
	</p>
	<p>
		<label for="amount">Product:</label>
		<br>
		<input type="text" name="product">
	</p>
	<p>
		<label for="amount">Email:</label>
		<br>
		<input type="text" name="email">
	</p>
	<p>
		<label for="amount">Transaction ID:</label>
		<br>
		<input type="text" name="transaction_id">
	</p>
	<input type="submit" value="do it">
</form>