<!DOCTYPE html>
<?php
require_once("mixpanel-php/lib/Mixpanel.php"); 
$mp = Mixpanel::getInstance("a1d4b97f7464ab307783602b0bd45373");
require_once("phpab.php"); 

$answer = $_POST['q3'];
$testvar = $_POST['variation'];
$gender = $_POST['gender'];
if ($gender == 'm') {
	$pronoun = 'ผม';
	$genderlong = 'male';
} else {
	$pronoun = 'ฉัน';
	$genderlong = 'female';
}

if ($answer==1) { $ansthai = 'เกาหลี '; $ansimg = 'korean'; }
elseif ($answer==2) { $ansthai = 'ไทย'; $ansimg = 'thai'; }
elseif ($answer==3) { $ansthai = 'ฝรั่งเศส '; $ansimg = 'french'; }
elseif ($answer==4) { $ansthai = 'อเมริกัน '; $ansimg = 'usa'; }
elseif ($answer==5) { $ansthai = 'แอฟริกา '; $ansimg = 'african'; }
else { $ansthai = 'เกาหลี '; $ansimg = 'korean'; }

$sharetitle = $pronoun.'ควรจะแต่งงานกับ'.$ansthai;
$sharedesc = 'ลองเข้าไปเล่นจะได้รู้ว่าควรจะคบกับคนประเทศใด';
$shareimg = 'http://www.sanookquiz.com/assets/'.$ansimg.$gender.'.jpg';


if($testvar == 'pink') {
	$mp->track("pageview", array("page" => "results", "variation" => "pink"));
	$mp->track("took test", array("result" => $ansimg, "variation" => "pink", "chosen gender" => $genderlong));
	} else {
	$mp->track("pageview", array("page" => "results", "variation" => "green"));
	$mp->track("took test", array("result" => $ansimg, "variation" => "green", "chosen gender" => $genderlong));
	}
	
	

?>

<html lang="th">
  <head>
		<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สนุกควิซ</title>
		<link rel="stylesheet" href="assets/bootstrap.min.css">
		<link rel="stylesheet" href="assets/style.css">
		
			<?php include_once("trackingcodes.php") ?>

		
  </head>
	<body <?php if($testvar == 'green') : ?>style="background-color:#D2FFBD;"<?php endif; ?>>
		
		<div class="container results">
			<div class="header">
				<h1 title="สนุกควิ! - SanookQuiz!"><img src="assets/title<?php if($testvar == 'green') : ?>green<?php endif; ?>.png"></h1>
			</div>
			<div class="content col-md-push-1 col-md-10 col-lg-8 col-lg-push-2">
			
			<div class="ad_wrap results1">
				<div class="ad_inner">
					<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
					<!-- SanookQuiz - results1 -->
					<ins class="adsbygoogle"
							 style="display:inline-block;width:336px;height:280px"
							 data-ad-client="ca-pub-4301586135506837"
							 data-ad-slot="4035105808"></ins>
					<script>
					(adsbygoogle = window.adsbygoogle || []).push({});
					</script>
				</div>
			</div>

			<div class="results_img">
				<img src="assets/<?php echo $ansimg.$gender; ?>.jpg">
			</div>
			
			<div class="sharebuts">
				<span class="facebook sharebut">
										<a onclick="var sTop=window.screen.height/2-(218);var sLeft=window.screen.width/2-(313);window.open('https://www.facebook.com/dialog/feed?display=popup&amp;app_id=1407351136204654&amp;link=http://www.sanookquiz.com&amp;picture=<?php print $shareimg; ?>&amp;name=<?php print $sharetitle; ?>&redirect_uri=http://www.sanookquiz.com&description=<?php echo $sharedesc; ?>','sharer','toolbar=0,status=0,width=580,height=400,top='+sTop+',left='+sLeft);return false;" class="fbshare">
						<img src="assets/fbicon.png" border="0" title="Share on Facebook"> <span class="sharetext">SHARE</span>
					</a>
				</span>
			</div>
			
			<div class="ad_wrap results2">
				<div class="ad_inner">
					<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
					<!-- SanookQuiz - results 2 -->
					<ins class="adsbygoogle"
							 style="display:inline-block;width:336px;height:280px"
							 data-ad-client="ca-pub-4301586135506837"
							 data-ad-slot="6569769805"></ins>
					<script>
					(adsbygoogle = window.adsbygoogle || []).push({});
					</script>
				</div>
			</div>

				
			</div>
		</div>			
  </body>
</html>
