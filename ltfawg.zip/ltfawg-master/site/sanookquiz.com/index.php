<!DOCTYPE html>
<?php require_once("phpab.php");
require_once("mixpanel-php/lib/Mixpanel.php");
$mp = Mixpanel::getInstance("a1d4b97f7464ab307783602b0bd45373");

$bgcolor_test = new phpab('bg');
$bgcolor_test->add_variation('green');
$testvar = $bgcolor_test->get_user_segment();


if($bgcolor_test->get_user_segment() == 'green') {
	$mp->track("pageview", array("page" => "test", "variation" => "green"));
	} else {
	$mp->track("pageview", array("page" => "test", "variation" => "pink"));
	}

?>
<html lang="th">
  <head>
		<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สนุกควิซ</title>
		<link rel="stylesheet" href="assets/bootstrap.min.css">
		<link rel="stylesheet" href="assets/style.css">
		<link href="assets/red.css" rel="stylesheet">
		<link href="assets/flat.css" rel="stylesheet">
		<script type="text/javascript" src="assets/jquery-1.11.0.min.js"></script>
		<script type="text/javascript" src="assets/bootstrap.min.js"></script>
		<script src="assets/icheck.min.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
				$('input').iCheck({
					radioClass: 'iradio_flat',
				});
			$genderok = 0;
			$weatherok = 0;
			$('.gender input')on('ifChecked', function(){
				$genderok = 1;
			});
			
			$('.q3 input')on('ifChecked', function(){
				$weatherok = 1;
			});
			
			$('#farangquiz').submit(function() {
return false;

			});
			});
    </script>
  </head>
	<body <?php if($bgcolor_test->get_user_segment() == 'green') : ?>style="background-color:#D2FFBD;"<?php endif; ?>>
		<?php include_once("trackingcodes.php") ?>
		<div class="container">
			<div class="header">
				<h1 title="สนุกควิ! - SanookQuiz!"><img src="assets/title<?php if($bgcolor_test->get_user_segment() == 'green') : ?>green<?php endif; ?>.png"></h1>
			</div>
			<div class="content col-md-push-1 col-md-10 col-lg-8 col-lg-push-2">
				<h3>คุณแต่งงานคนประเทศใดดี</h3>

				<div class="ad_wrap ad1">
					<div class="ad_inner">
						<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
						<!-- SanookQuiz - ad1 -->
						<ins class="adsbygoogle"
								 style="display:inline-block;width:336px;height:280px"
								 data-ad-client="ca-pub-4301586135506837"
								 data-ad-slot="3395977407"></ins>
						<script>
						(adsbygoogle = window.adsbygoogle || []).push({});
						</script>
					</div>
				</div>
				<div class="quiz_img">
					<img src="assets/wedding.jpg">
				</div>

				<form id="farangquiz" name="farangquiz" class="quiz" action="results" method="POST" onsubmit="return validateSubmit(this)">
					<div class="questions cf">
						
						<div class="question gender">
							<h4>อยากแต่งงานกับผู้ชายหรือผู้หญิง</h4>
							<div class="answer male"><input type="radio" name="gender" id="male" value="m"><label for="male">ผู้ชาย</label></div>
							<div class="answer female"><input type="radio" name="gender" id="female" value="f"><label for="female">ผู้หญิง</label></div>
						</div>
					
						<div class="question q1">
							<h4>สีผิวที่ต้องการ</h4>
							<div class="answer"><input type="radio" name="q1" id="q1a" value="1"><label for="q1a">สีขาว</label></div>
							<div class="answer"><input type="radio" name="q1" id="q1b" value="2"><label for="q1b">สีแทน</label></div>
							<div class="answer"><input type="radio" name="q1" id="q1c" value="3"><label for="q1c">สีดำ</label></div>
							<div class="answer"><input type="radio" name="q1" id="q1d" value="4"><label for="q1d">ฉันตาบอดสี </label></div>
						</div>
						
						<div class="question q2">
							<h4>เศรษฐกิจ</h4>
							<div class="answer"><input type="radio" name="q2" id="q2a" value="1"><label for="q2a">ร่ำรวย</label></div>
							<div class="answer"><input type="radio" name="q2" id="q2b" value="2"><label for="q2b">อยู่แบบสะดวกสบายพอสำหรับฉัน </label></div>
							<div class="answer"><input type="radio" name="q2" id="q2c" value="3"><label for="q2c">ความรักเป็นสิ่งที่สำคัญกว่าปริมาณเงิน</label></div>
						</div>

						<div class="ad_wrap ad2">
							<div class="ad_inner">
								<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
								<!-- SanookQuiz - ad2 -->
								<ins class="adsbygoogle"
										 style="display:inline-block;width:336px;height:280px"
										 data-ad-client="ca-pub-4301586135506837"
										 data-ad-slot="6349443809"></ins>
								<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
								</script>
							</div>
						</div>
						
						<div class="question q3">
							<h4>ภูมิอากาศของประเทศ</h4>
							<div class="answer"><input type="radio" name="q3" id="q3a" value="1" class="required"><label for="q3a">หนาวแล้วมีหิมะตกบ้าง</label></div>
							<div class="answer"><input type="radio" name="q3" id="q3b" value="2"><label for="q3b">ไม่หนาวมากพออยู่ได้</label></div>
							<div class="answer"><input type="radio" name="q3" id="q3c" value="3"><label for="q3c">หนาวเย็นแบบขั้วโลก</label></div>
							<div class="answer"><input type="radio" name="q3" id="q3d" value="4"><label for="q3d">ร้อนชื้น </label></div>
							<div class="answer"><input type="radio" name="q3" id="q3f" value="4"><label for="q3f">ทุ่งหญ้ากึ่งทะเลทราย </label></div>
						</div>
											
						<div class="question q4">
							<h4>รูปร่างลักษณะ</h4>
							<div class="answer"><input type="radio" name="q4" id="q4a" value="1"><label for="q4a">สูง</label></div>
							<div class="answer"><input type="radio" name="q4" id="q4b" value="2"><label for="q4b">ผอม</label></div>
							<div class="answer"><input type="radio" name="q4" id="q4c" value="3"><label for="q4c">เตี้ย</label></div>
							<div class="answer"><input type="radio" name="q4" id="q4d" value="4"><label for="q4d">อ้วน </label></div>
						</div>
						
						<div class="question q5">
							<h4>รสชาติอาหาร</h4>
							<div class="answer"><input type="radio" name="q5" id="q5a" value="1"><label for="q5a">รสจัด</label></div>
							<div class="answer"><input type="radio" name="q5" id="q5b" value="2"><label for="q5b">รสจืด</label></div>
							<div class="answer"><input type="radio" name="q5" id="q5c" value="3"><label for="q5c">เน้นเนื้อสัตว์</label></div>
							<div class="answer"><input type="radio" name="q5" id="q5d" value="4"><label for="q5d">เน้นผักและผลไม้ </label></div>
							<div class="answer"><input type="radio" name="q5" id="q5e" value="5"><label for="q5e">ทุกประเภท </label></div>
						</div>
						
						<div class="ad_wrap ad3">
							<div class="ad_inner">
								<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
								<!-- SanookQuiz - ad3 -->
								<ins class="adsbygoogle"
										 style="display:inline-block;width:336px;height:280px"
										 data-ad-client="ca-pub-4301586135506837"
										 data-ad-slot="7826177007"></ins>
								<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
								</script>
							</div>
						</div>
						
						<div class="question q6">
							<h4>คุณอยากอยู่ทวีปใด</h4>
							<div class="answer"><input type="radio" name="q6" id="q6a" value="1"><label for="q6a">เอเซีย</label></div>
							<div class="answer"><input type="radio" name="q6" id="q6b" value="2"><label for="q6b">อเมริกาเหนือ</label></div>
							<div class="answer"><input type="radio" name="q6" id="q6c" value="3"><label for="q6c">อเมริกาใต้</label></div>
							<div class="answer"><input type="radio" name="q6" id="q6d" value="4"><label for="q6d">ยุโรป </label></div>
							<div class="answer"><input type="radio" name="q6" id="q6e" value="5"><label for="q6e">แอฟริกา </label></div>
							<div class="answer"><input type="radio" name="q6" id="q6f" value="6"><label for="q6f">ออสเตรเลีย </label></div>
						</div>
					
					</div>
					
					<input type="hidden" name="variation" value="<?php echo $testvar; ?>">
					<button class="submit" type="submit">ดูคำตอบ</button>
					
				</form>
			</div>
		</div>			
  </body>
</html>
