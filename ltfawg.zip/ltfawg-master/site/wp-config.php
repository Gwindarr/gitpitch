<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */



// Check for a local config file
if ( file_exists( dirname( __FILE__ ) . '/local-config.php' ) ) {
	define( 'WP_LOCAL_DEV', true );
	include( dirname( __FILE__ ) . '/local-config.php' );
} else {
	define( 'WP_LOCAL_DEV', false );

	// ** MySQL settings - You can get this info from your web host ** //
	/** The name of the database for WordPress */
	define('DB_NAME', 'ltfawg_wp');

	/** MySQL database username */
	define('DB_USER', 'ltfawg_wp');

	/** MySQL database password */
	define('DB_PASSWORD', 'FcT1lLnoz7Jz');

	/** MySQL hostname */
	define('DB_HOST', 'localhost');

	/** Database Charset to use in creating database tables. */
	define('DB_CHARSET', 'utf8');

	/** The Database Collate type. Don't change this if in doubt. */
	define('DB_COLLATE', '');
}


/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Hv&]|RMb*j|Eu&<}s[{WM7APfH)U91]Y-)7iXI T^ @J0xOz`OA/%@1lV,LUB-sD');
define('SECURE_AUTH_KEY',  '|!B[I-kIi+8&gonsdQQ0!dh#`8hDMfP<-;Ae (IZ|7iF+Y72*1|{1VUUlW&NU,(s');
define('LOGGED_IN_KEY',    'PYNKgrBv|xPs@@PdhCL<q1+|a/A-,Xiz[q^|~52hMUNn}M~P|UMy=*>Zl<X#/pT~');
define('NONCE_KEY',        '_UvJ%f{jvCL4b?nZ`H:vI~:oaZ~a)>csFWf5G^FdZ<Wn._=VTW7z4IMof@id4j9&');
define('AUTH_SALT',        'U*$G+5l;sY](z$hsFW`#cp7+(svl,pQo-t48n=4eL)FVU._v%-47F;D?dr<W&n?|');
define('SECURE_AUTH_SALT', 'GfyRPpEs--wq*%Lb`E{|H+r%`XHm5w+-5a/-Of-sqRaTX`cePP6xDpM7wRlWB+ z');
define('LOGGED_IN_SALT',   'w9n|#bwmv~#l]h vm}*T?XLp7`*x~#8O|Ec$_}Sf^!<(zvy-4>XmMTt?6A)K*+*.');
define('NONCE_SALT',       'SpaZVV6zu*?N*h^ wj<|tLU4#I~d*4B4k4D$j9+V!5bPeLL<<}2$glM8P>)0o&S`');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

