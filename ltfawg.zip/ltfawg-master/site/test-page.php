
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Learn Thai Online - Learn Thai From A White Guy</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
	<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,300italic,400italic,700italic|Open+Sans:400,300,300italic,400italic,600italic,600,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="/wp-content/themes/learn-thai/style.css?ver=0.0.2" type="text/css">
	<!-- wp_head -->

<!-- This site is optimized with the Yoast WordPress SEO plugin v2.2.1 - https://yoast.com/wordpress/plugins/seo/ -->
<!-- Admin only notice: this page doesn't show a meta description because it doesn't have one, either write it for this page specifically or go into the SEO -> Titles menu and set up a template. -->
<link rel="canonical" href="http://learnthaifromawhiteguy.com/new-learn-thai-online/" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Learn Thai Online - Learn Thai From A White Guy" />
<meta property="og:url" content="http://learnthaifromawhiteguy.com/new-learn-thai-online/" />
<meta property="og:site_name" content="Learn Thai From A White Guy" />
<meta property="fb:admins" content="689928716" />
<meta property="og:image" content="http://learnthaifromawhiteguy.com/ogimg.png" />
<meta name="twitter:card" content="summary"/>
<meta name="twitter:title" content="Learn Thai Online - Learn Thai From A White Guy"/>
<meta name="twitter:site" content="@LTfaWG"/>
<meta name="twitter:domain" content="Learn Thai From A White Guy"/>
<meta name="twitter:image:src" content="http://learnthaifromawhiteguy.com/ogimg.png"/>
<meta name="twitter:creator" content="@andregoncalves"/>
<!-- / Yoast WordPress SEO plugin. -->

<link rel="alternate" type="application/rss+xml" title="Learn Thai From A White Guy &raquo; Feed" href="http://learnthaifromawhiteguy.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Learn Thai From A White Guy &raquo; Comments Feed" href="http://learnthaifromawhiteguy.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/learnthaifromawhiteguy.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.4.1"}};
			!function(a,b,c){function d(a){var c,d=b.createElement("canvas"),e=d.getContext&&d.getContext("2d");return e&&e.fillText?(e.textBaseline="top",e.font="600 32px Arial","flag"===a?(e.fillText(String.fromCharCode(55356,56806,55356,56826),0,0),d.toDataURL().length>3e3):"diversity"===a?(e.fillText(String.fromCharCode(55356,57221),0,0),c=e.getImageData(16,16,1,1).data.toString(),e.fillText(String.fromCharCode(55356,57221,55356,57343),0,0),c!==e.getImageData(16,16,1,1).data.toString()):("simple"===a?e.fillText(String.fromCharCode(55357,56835),0,0):e.fillText(String.fromCharCode(55356,57135),0,0),0!==e.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag"),unicode8:d("unicode8"),diversity:d("diversity")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag&&c.supports.unicode8&&c.supports.diversity||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='lang-quiz-css-css'  href='http://learnthaifromawhiteguy.com/wp-content/plugins/lang-quiz//css/lang-quiz.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='bonobocss-css'  href='http://learnthaifromawhiteguy.com/wp-content/plugins/bonobo/bonobo.css?ver=4.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='membermouse-main-css'  href='http://learnthaifromawhiteguy.com/wp-content/plugins/membermouse/resources/css/common/mm-main.css?ver=2.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='membermouse-buttons-css'  href='http://learnthaifromawhiteguy.com/wp-content/plugins/membermouse/resources/css/common/mm-buttons.css?ver=2.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='membermouse-font-awesome-css'  href='//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css?ver=4.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='wdb-style-css'  href='http://learnthaifromawhiteguy.com/wp-content/plugins/word-highlighting//css/wdb-style.css?ver=0.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='little-hippo-plugin-styles-css'  href='http://learnthaifromawhiteguy.com/wp-content/plugins/little-hippo/public/assets/css/public.css?ver=1.1.4' type='text/css' media='all' />
<link rel='stylesheet' id='custom-style-css'  href='http://learnthaifromawhiteguy.com/wp-content/themes/learn-thai/css/custom.css?ver=0.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='faking-fluency-style-css'  href='http://learnthaifromawhiteguy.com/wp-content/themes/learn-thai/css/fakingfluency.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://learnthaifromawhiteguy.com/wp-includes/css/dashicons.min.css?ver=4.4.1' type='text/css' media='all' />
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/bonobo/bonobo.js?ver=4.4.1'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/bonobo/shuffle.js?ver=4.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var MemberMouseGlobal = {"jsIsAdmin":"","adminUrl":"http:\/\/learnthaifromawhiteguy.com\/wp-admin\/","globalurl":"http:\/\/learnthaifromawhiteguy.com\/wp-content\/plugins\/membermouse","checkoutProcessingPaidMessage":"Please wait while we process your order...","checkoutProcessingFreeMessage":"Please wait while we create your account...","checkoutProcessingMessageCSS":"mm-checkout-processing-message","currencyInfo":{"currency":"USD","postfixIso":false,"name":"United States Dollar","int_curr_symbol":"&#85;&#83;&#68;&#32;","currency_symbol":"$","mon_decimal_point":".","mon_thousands_sep":",","mon_grouping":"3;3","positive_sign":"","negative_sign":"","int_frac_digits":"2","frac_digits":"2","p_cs_precedes":"1","p_sep_by_space":"0","n_cs_precedes":"1","n_sep_by_space":"0","p_sign_posn":"1","n_sign_posn":"1"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/membermouse/resources/js/global.js?ver=2.2.4'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/membermouse/resources/js/common/mm-common-core.js?ver=2.2.4'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/membermouse/resources/js/user/mm-preview.js?ver=2.2.4'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/little-hippo/public/assets/js/public.js?ver=1.1.4'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/optin-monster/assets/js/api.js?ver=2.1.7'></script>
<link rel='https://api.w.org/' href='http://learnthaifromawhiteguy.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://learnthaifromawhiteguy.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://learnthaifromawhiteguy.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 4.4.1" />
<link rel='shortlink' href='http://learnthaifromawhiteguy.com/?p=5773' />
<link rel="alternate" type="application/json+oembed" href="http://learnthaifromawhiteguy.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flearnthaifromawhiteguy.com%2Fnew-learn-thai-online%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://learnthaifromawhiteguy.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flearnthaifromawhiteguy.com%2Fnew-learn-thai-online%2F&#038;format=xml" />

<div id="mm-preview-settings-bar" style="margin-top:0px; display: none;">
	<div style="float:left;">
		<span style="margin-right:10px;">
			MM Preview Settings <a title="When you're logged in as an administrator you can use the options to the right to preview your site with different access rights and at different times during the membership.The options available to you will dynamically change based on what access rights you've used to protect content and the drip content schedules you've defined."><i class="fa fa-info-circle mm-icon grey" style=" font-size:1.3em; position:relative; top:2px;"></i></a>		</span>
		<a title="Select your membership level"><i class="fa fa-user mm-icon grey" style=" font-size:1.3em; position:relative; top:2px; margin-right:4px;"></i></a>		<select name="mm-preview-member_type" id='mm-preview-member_type' onchange="mmPreviewJs.changeMembershipLevel()">
			<option value='5'  >Basic Fluency (Need to Know Sentence Pack)</option>
<option value='4'  >First Three Lessons</option>
<option value='1' selected >Free Membership</option>
<option value='3'  >Read Thai in 2 Weeks (Web Course) </option>
<option value='7'  >Thai Basic Fluency 1</option>
<option value='6'  >Thai Fluency 1</option>
<option value='none'  >Non-Members</option>
		</select>
	</div>

	<div id="mm-member-options" style="float:left; margin-left:5px;">
		<div id='mm-show-at' style="float:left; margin-left:15px;">
					<div style='float:left; vertical-align:middle;'><a id='mm-showhide-preview-link' onclick="mmPreviewJs.showAccessTags()" style='cursor: pointer;' title='Select the bundles you have applied'><i class="fa fa-cube mm-icon grey" style=" font-size:1.3em; position:relative; top:2px;"></i></a></div>
			<div id='mm-applied-tag-count' style='float:left; padding-left: 5px; padding-right: 5px; vertical-align:middle;'>1</div> <div style='float:left;  vertical-align:middle;'>bundles applied</div>
				<span style="margin-left: 15px;">
			<a title="Select the number of days you've been a member"><i class="fa fa-calendar mm-icon grey" style=" font-size:1.3em; position:relative; top:1px;"></i></a>			<select name="mm-preview-days" id='mm-preview-days' onchange="mmPreviewJs.enableChangeButton();" >
				<option value='0' selected >0</option>
			</select>
		</span>
		</div>
		<a onclick="mmPreviewJs.savePreview()" class="mm-button small black" style="margin-left: 15px; box-shadow: 0 0px 1px #EAEAEA, 0 1px 0 #868686 inset">Save</a>


					<div id='mm-preview-access-tags' style='height: 70px;'>
				<div id='mm-preview-access-tag-results'	>
				<select multiple="multiple" rows='6' style='width: 98%;' id='preview_access_tags'  name='preview_access_tags[]'  onchange="mmPreviewJs.changeBundles();">
					<option value='3'  >Lesson Pack 2</option>
<option value='4'  >Need to Know Sentence Pack</option>
				</select>
				</div>
			</div>
			</div>

	<div style="float:right; margin-right:20px; ">
		<a href="http://learnthaifromawhiteguy.com/wp-admin/admin.php?page=general_settings&module=other_settings#preview-settings-bar-options" target="_blank" class="mm-button small black" style="margin-left: 15px; box-shadow: 0 0px 1px #EAEAEA, 0 1px 0 #868686 inset">Hide this bar</a>
	</div>
</div><meta name="google-site-verification" content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw" />	<!-- /wp_head -->
</head>
<body class="page page-id-5773 page-template page-template-page_learn_thai_online page-template-page_learn_thai_online-php logged-in custom-header header-full-width content-sidebar post-type-page" data-current-user-id="2233">
	<!-- Google Tag Manager -->
<script>
console.info("Initializing GTM TESTING");
console.table(window.dataLayer);
</script>
<!-- End Google Tag Manager -->

		<header class="header">
			<div id="main-nav" class="navbar navbar-inverse bs-docs-nav" role="banner">
				<div class="container">
					<div class="navbar-header responsive-logo">
						<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a href="/" class="navbar-brand">
							<img src="/wp-content/themes/learn-thai/images/brett-logo.svg" alt="Learn Thai From A White Guy" style="max-width: 50px">
							<span class="hidden-sm title">Learn Thai from a White Guy</span>
						</a>
					</div>

					<nav class="navbar-collapse bs-navbar-collapse collapse" role="navigation" id="site-navigation">
						<ul id="menu-primary-navigation" class="nav navbar-nav navbar-right responsive-nav main-nav-list">
														<li id="menu-item-1385" class="menu-item menu-item-type-custom menu-item-object-custom">
								<a href="/home-1">Home</a>
							</li>
																					<li id="menu-item-3675" class="menu-item menu-item-type-custom menu-item-object-custom">
								<a href="/lesson/introduction">Web Course</a>
							</li>
														<li id="menu-item-3221" class="menu-item menu-item-type-post_type menu-item-object-page">
								<a target="_blank" href="/learn-thai-blog/" title="Learn Thai Blog">Blog</a>
							</li>
							<li id="menu-item-3244" class="menu-item menu-item-type-post_type menu-item-object-page">
								<a target="_blank" href="/ask-brett/" title="Contact Brett from Learn Thai Online">Contact Me</a>
							</li>
															<li class="menu-item"><a href="/home">My Account</a></li>
								<li class="menu-item"><a class="" href="/logout">Logout</a></li>
													</ul>
					</nav>
				</div>
			</div>
		<div class="clear"></div>
</header>


<div id="content" class="site-content" >

	<div style="display: none; background: url(/wp-content/themes/learn-thai/images/hero.jpg) no-repeat; background-attachment: fixed; background-size: cover">
		<div class="header-content-wrap">
			<div class="container">
				<h1 class="intro-text">Learn to Read Thai in 2 Weeks with my Easy Online Course</h1>
				<h2 class="intro-text-sub">The best Thai course on the web</h2>
				<div class="buttons">
					<div class="cta-buttons" style="display: none">
						<a href="#pick-a-course" class="btn btn-primary custom-button red-btn animated-scroll">
							Pick a Course <i class="fa fa-chevron-down" style="vertical-align: initial; margin-left: 0.5em"></i>
						</a>
						<a href="#" class="btn btn-primary custom-button blue-btn reveal-optin">
							Try 4 Lessons Free <i class="fa fa-star" style="vertical-align: initial; margin-left: 0.5em"></i>
						</a>
					</div>
					<div class="opt-in-form" style="display: block">
						<form accept-charset="utf-8" action="http://www.aweber.com/scripts/addlead.pl" method="post">
							<input id="email-optin-header" placeholder="Enter your email..." type="text" name="email" class="form-control input-box">
							<input type="hidden" name="name" value="Friend">
							<input type="hidden" name="listname" value="free_optin">
							<input type="hidden" name="meta_forward_vars" value="0">
							<input type="hidden" name="meta_message" value="1">
							<input type="hidden" name="meta_required" value="email">
							<input type="hidden" name="redirect" value="http://learnthaifromawhiteguy.com/confirm-signup?utm_nooverride=1">
							<input type="submit" name="submit" value="Try 4 Lessons Free">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<section class="benefits" style="background: #FFF">
		<div class="container">
			<div class="section-header">
				<h2 class="dark-text">Learn to Read Thai in 2 Weeks</h2>
				<h6></h6>
			</div>
			<div class="row" style="text-align: left; font-size: 1.5em">
				<div class="col-lg-8 col-md-8 column" style="text-align: left">
					<p>
						My first Thai course has everything you need to read and start speaking Thai. No boring fake dialogues or useless kids' books here - I'm just going to tell you exactly what you need to know and how to practice it. I've been perfecting my method for over 10 years and many hundreds students have used it. I know it works and I know it'll work for you.
					</p>
					<p>
						The course should take you about <span style="text-decoration:underline">2 weeks to complete</span>. You'll need to review the material everyday, but when you finish I guarantee you'll be able to do all of the following stuff:
					</p>
				</div>
				<div class="col-lg-4 col-md-4 column" style="text-align: right">
					<img src="http://cdn.optimizely.com/img/2446361790/1d64c3406fe3483e9311b5371d995df9.jpg" alt="Brett from Learn Thai from a White Guy" style="max-width: 200px">
				</div>
			</div>
			<div class="row" style="background:#FCF8E3; margin-top: 50px">
				<div class="col-md-4">
					<h4>Know How to Pronounce Everything Correctly!</h4>
					<img src="/wp-content/themes/news/images/sounds.jpg">
					<p>Puzzled by prounciation? Terrible with tones? Once you are a few hours into my course, it will all become clear</p>
				</div>

				<div class="col-md-4">
					<h4>Thai People will Actually Understand You!<br>&nbsp;</h4>
					<img src="/wp-content/themes/news/images/people.jpg">
					<p>Do Thai people ever struggle to understand what you are saying?  It's time to fix that.</p>
				</div>

				<div class="col-md-4">
					<h4>You'll Be Able to Read Signs and Menus!<br>&nbsp;</h4>
					<img src="/wp-content/themes/news/images/signs.jpg">
					<p>You won't be able to understand a novel or newspaper yet, but after my course you'll be able to work through menus and signs with ease.</p>
				</div>
			</div>
		</div>
	</section>


	<section class="focus" id="opt-in" style="border-top: 1px solid #ccc">
		<div class="container">
			<div class="section-header">
				<h2>Buy Now and Get <span class="discount">$20 off!</span></h2>
			</div>

			<div class="row">

				<div class="buy-now-block" style="text-align: center; width: 600px; margin: auto; background: #EEE; padding: 50px 0; margin-bottom: 2em">

					<img src="http://cdn.optimizely.com/img/2446361790/1d64c3406fe3483e9311b5371d995df9.jpg" alt="Brett from Learn Thai from a White Guy" style="max-width: 200px; display: inline-block">
				</div>
			</div>

			<div class="row center-align">
				<a href="https://learnthaifromawhiteguy.com/checkout/?rid=p3dOIg&ref=sales-page" class="btn btn-primary btn-lg custom-button blue-btn"  style="font-size: 2em">
					Buy Now
				</a>
			</div>


			<dic class="row" style="margin-top: 3em">
				"Brett's ability to unravel the mystery has really opened up a lot of doors for me"
				<div class="client" style="color:#000; padding-top: 1em">
					<div class="quote">
						Matt from UK
					</div>
				</div>
		</div>
	</section>

	<section class="about-us" id="aboutus" style="background: #EEE; color: #404040">
		<div class="container" style="font-size: 1.25em; text-align:left">
			<div class="row">
				<div class="col-md-6">
					<iframe width="480" height="294" src="//www.youtube.com/embed/dH3J93K4eWI" frameborder="0" allowfullscreen=""></iframe>
				</div>
				<div class="col-md-6">
					"Immediately when I saw Brett's site Learn Thai From A White Guy, I knew it was the best site to learn from. With my experience studying languages, I knew this guy knew what he was doing. <strong>2 weeks later I can officially read Thai.</strong>
My private tutor is amazed at how quick I have progressed at learning the tones and reading the letters. If you are debating whether to buy Brett's course or not, don't. Just do it."
					<div class="client" style="padding-top: 1em;  text-align: right">
						<div class="quote">
							Phillip
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="focus" id="">
		<div class="container">
			<div class="section-header">
				<h2 class="">Hi, I'm Brett the White Guy</h2>
			</div>
			<div class="row" data-scrollreveal="enter right after 0s over 1s"  style="font-size: 1.25em; text-align: left">
				<div class="col-lg-8 col-md-8 column" style="text-align: left">
					<div data-scrollreveal="enter left after 0s over 1s">
						Hi, I'm Brett.  I got so frustrated that there weren't any good resources for mastering the script and sound system of the Thai language that I went and made my own.<br>
						<br>
						If you think you're tone-deaf, or bad at learning languages, I can help. Because, I was driven crazy by all the same things as you you and I've come up with a better way to get you to fluency.
					</div>
					&nbsp
					<div>
						<strong>I really struggled in the beginning, but I managed to get fluent without ever studying at a school.</strong><br>I spent 10 years developing and testing my system and now I want to help you to skip many of the unnecessary and frustrating mistakes that I made. If you spend ten hours on my course, I guarantee you'll be speaking and reading by the time you're done. It worked for me and it's worked for thousands of my students, and I guarantee it will work for you.
					</div>
				</div>
				<div class="col-lg-4 col-md-4 column">
					<img src="/wp-content/themes/learn-thai/images/brett-cappadocia.jpg" alt="Brett from Learn Thai from a White Guy" style="max-width: 260px">
				</div>
			</div>
			<div class="row">
				<div class="col-md-12" style="text-align: center">
					<h3>Here's What You Get:</h3>
				</div>
			</div>
			<div class="row" data-scrollreveal="enter right after 0s over 1s"  style="font-size: 1em; text-align: center; background: #FCF8E3">
				<div class="col-md-4">
					<h3>Over 50 In-Depth Lessons</h3>
					<img src="/wp-content/themes/news/images/39lessons.png">
					<p style="padding-top: 1em">My course covers everything you need to know to read Thai.  This includes all the consonants, vowels as well as how to determine the tone of each word.  There are in-course flashcards in the lessons to help you practice.  </p>
				</div>
				<div class="col-md-4">
					<h3>Clickable Audio</h3>
					<div class="audio-row" style="height: 140px; font-size:4em; background: #FFF">
						<a class="speech audio_link">ก</a>
						<a class="speech audio_link">ม</a>
						<a class="speech audio_link">ด</a>
						<p style="font-size: 1.5rem">(click each letter)</p>
					</div>
					<p style="padding-top: 1em">Everything single Thai letter or word in my web course has clickable audio recorded by a professional voice artist.  Part of learning a language is listening over and over again and you'll be wanting to click on those words a lot!</p>
				</div>
				<div class="col-md-4">
					<h3>600+ Digital Flash Cards</h3>
					<img src="/wp-content/themes/news/images/anki.jpg">
					<p style="padding-top: 1em">I made a special set of flash cards specifically for this course, complete with audio for every one. The flash cards work with <a href="http://ankisrs.net" target="_blank">Anki</a> software, so the deck will intelligently pick which cards you need to review and will sync your progress to your phone, tablet or other computers.</p>
				</div>
			</div>
		</div>
	</section>

	<section class="about-us" id="aboutus" style="background: #EEE; color: #404040">
		<div class="container" style="font-size: 1.25em; text-align:left">
			<div class="row">
				<div class="col-md-6">
					<iframe width="480" height="294" src="http://www.youtube.com/embed/r__W_2BvvRs" frameborder="0" allowfullscreen=""></iframe>
				</div>
				<div class="col-md-6">
					"I will admit that I was skeptical about your course for many reasons, and EVERY SINGLE doubt I had before purchasing was silly and pointless, and I knew this by about the second day of studying, because <strong>my wife is a native Thai speaker and she couldn't contain her surprise</strong> at how successful my accent and proficiency became after I began using your course."
					<div class="client" style="padding-top: 1em; text-align: right">
						<div class="quote">
							Mike Oppenheim
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="testimonial" id="testimonials" style="background: #FFF">
		<div class="container"><div class="section-header">
			<h2 class="">Join the thousands of people that learned to read and speak Thai!</h2>
		</div>
		<div class="row" data-scrollreveal="enter right after 0s over 1s">
			<div class="col-md-12">
				<div id="client-feedbacks" class="owl-carousel owl-theme">
					<div class="widget zerif_testim">
						<div class="feedback-box" style="background: #EEE">
							<div class="message">I'm blown away by the progress I've made. I can read anything in Thai, understand the tone and properly pronounce it. <span class="visible-xs-inline show-more-message">...<br><a href="#">Show more <i class="fa fa-chevron-down"></i></a></span><span class="hidden-xs hidden-msg">After learning how to read, he started teaching me practical vocabulary, sentence structure and how to speak like a Thai (which is way different than what most language books will teach you, of course). I live in Thailand and my experience here has drastically improved since studying with Brett. I've been sending fellow expats his way ever since my first lesson - this guy knows what he's doing.</span>
							</div>
							<div class="client">
								<div class="quote red-text">
									<i class="icon-fontawesome-webfont-294"></i>
								</div>
								<div class="client-info">
									<a class="client-name" target="_blank">Travis from USA</a>
								</div>
								<div class="client-image">
									<img src="/wp-content/themes/learn-thai/images/quote-travis.jpg" alt="">
								</div>
							</div>
						</div>
					</div>

					<div class="widget zerif_testim">
						<div class="feedback-box" style="background: #EEE">
							<div class="message">Been studying with the white guy for almost a year now, that should tell its own story. You really do get the alphabet <span class="visible-xs-inline show-more-message">...<br><a href="#">Show more <i class="fa fa-chevron-down"></i></a></span><span class="hidden-xs hidden-msg">cracked in a matter of hours!! Brett's ability to unravel the mystery has really opened up a lot of doors for me. Every lesson I'm learning new material, on stuff I want to learn about. I feel so confident holding conversations knowing the language I'm using is the real deal!! No more over-polite robot speech!! This confidence combined with a no-pressure learning environment is what keeps me coming back for more!!</span>
							</div>
							<div class="client">
								<div class="quote red-text">
									<i class="icon-fontawesome-webfont-294"></i>
								</div>
								<div class="client-info">
									<a class="client-name" target="_blank">Matt from UK</a>
								</div>
								<div class="client-image">
									<img src="/wp-content/themes/learn-thai/images/quote-matt.jpg" alt="">
								</div>
							</div>
						</div>
					</div>

					<div class="widget zerif_testim">
						<div class="feedback-box" style="background: #EEE">
							<div class="message">In 3 hours, I'd pummeled the thai alphabet into my head. All those squiggly lines and curly characters? <span class="visible-xs-inline show-more-message">...<br><a href="#">Show more <i class="fa fa-chevron-down"></i></a></span><span class="hidden-xs hidden-msg">I know 'em. It's been a smooth ride ever since. 3 months down the road and I can read pretty much everything (and understand a helluva lot more of what's going on around me). This makes living in Thailand a blast. Also, when I hear other foreigners speaking Thai who haven't learned the alphabet, they sound ridiculous and nothing like the way they should sound.</span>
							</div>
							<div class="client">
								<div class="quote red-text">
									<i class="icon-fontawesome-webfont-294"></i>
								</div>
								<div class="client-info">
									<a class="client-name" target="_blank">John from Australia</a>
								</div>
								<div class="client-image">
									<img src="/wp-content/themes/learn-thai/images/quote-john.jpg" alt="">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class="focus" id="opt-in" style="padding: 50px 0">
		<div class="container">
			<div class="section-header">
				<h2 class="dark-text">What are you waiting for? Start learning Thai today!</h2>
				<h6></h6>
			</div>
			<div class="row" style="font-size: 1.25em; text-align: left; padding-bottom: 1em">
				<div class="col-md-12">
					My first web course has over 50 lessons for <b>only $127</b>. Like I said, it takes about 2 weeks to get through all the material in the course, but you'll have <b>lifetime access</b>. You'll also have unlimited email support while using the course so you can email me whenever you have questions.
				</div>
			</div>

			<div class="row" style="font-size: 1.25em; text-align: left; padding: 1em 0; border-top: 1px solid #ccc; border-bottom: 1px solid #ccc">
				<div class="col-md-3" style="text-align: center">
					<img src="/wp-content/themes/news/images/guarantee.png">
				</div>
				<div class="col-md-9">
					When you get my web course, you get a 100% money-back guarantee. That means that you can learn how to read, write, say everything correctly and communicate more effectively. But if you are dissatisfied with the course for any reason whatsoever, just let me know within 30 days I'll give you a full refund no questions asked.
				</div>
			</div>

			<div class="row" style="padding-top: 1em">

				<div style="text-align: center;" class="buy-now-block">
					<h2>Buy Now and Get <span class="discount">$20 off!</span></h2>
					<a href="https://learnthaifromawhiteguy.com/checkout/?rid=p3dOIg&ref=sales-page" class="btn btn-primary btn-lg custom-button blue-btn" style="font-size: 2em">
						Buy Now
					</a>
				</div>
			</div>
		</div>
	</section>
</div>
	<footer id="footer">
		<p>Copyright 2016 Learn Thai From A White Guy</p>
	</footer>
	<script type="text/javascript" src="http://analytics.aweber.com/js/awt_analytics.js?id=3cWB"></script>
<div id="mm-payment-options-dialog"></div>
<div id="mm-payment-confirmation-dialog"></div>
<script>
jQuery(document).ready(function(){
	if(jQuery.isFunction("dialog")) {
		jQuery("#mm-payment-options-dialog").dialog({autoOpen: false});
		jQuery("#mm-payment-confirmation-dialog").dialog({autoOpen: false});
	}
});
</script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/clickable-audio//js/speech.js?ver=4.4.1'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/lang-quiz//js/lang-quiz.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/plugins/word-highlighting/js/wdb-engine.js?ver=4.4.1'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/themes/learn-thai/js/bootstrap.min.js?ver=5.0.0'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/themes/learn-thai/js/custom.js?ver=5.0.1'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-content/themes/learn-thai/js/fakingfluency.js?ver=5.0.1'></script>
<script type='text/javascript' src='http://learnthaifromawhiteguy.com/wp-includes/js/wp-embed.min.js?ver=4.4.1'></script>
</body>
</html>