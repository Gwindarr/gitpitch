<?php
$price = 97;
$discount = 147-$price;
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Thai Script: First Look - Learn Thai From A White Guy - Learn Thai Online</title>

	<link href="https://learnthaifromawhiteguy.com/thai-script/" rel="canonical">

	<?php include 'wp-content/themes/news-faking-fluency/_analytics.php'; ?>

	<meta property="og:locale" content="en_US">
	<meta property="og:type" content="en_US">
	<meta property="og:title" content="Thai Script: First Look - Learn Thai From A White Guy - Learn Thai Online">
	<meta property="og:description" content="Learning to read Thai is the most important step you will be taking on your journey to learn Thai. This course is going to attempt to help familiarise you with how the Thai script works and give you actual examples of very common words and phrases even before you know how to read. This will &hellip;">
	<meta property="og:url" content="https://learnthaifromawhiteguy.com/thai-script/">
	<meta property="og:site_name"content="Learn Thai From A White Guy - Learn Thai Online">
	<meta property="fb:admins" content="689928716">
	<meta property="og:image" content="https://learnthaifromawhiteguy.com/ogimg.png" >

	<meta name="twitter:card" content="summary">
	<meta name="twitter:description" content="Learning to read Thai is the most important step you will be taking on your journey to learn Thai. This course is going to attempt to help familiarise you with how the Thai script works and give you actual examples of very common words and phrases even before you know how to read. This will [&hellip;]">
	<meta name="twitter:title" content="Thai Script: First Look - Learn Thai From A White Guy - Learn Thai Online" >
	<meta name="twitter:site" content="@LTfaWG" >
	<meta name="twitter:image" content="https://learnthaifromawhiteguy.com/ogimg.png" >
	<meta name="twitter:creator" content="@LTfaWG">

	<link href='//maxcdn.bootstrapcdn.com' rel='dns-prefetch'>
	<link href='//s.w.org' rel='dns-prefetch'>
	<link href="//ajax.googleapis.com" rel='dns-prefetch'>

	<link href="https://learnthaifromawhiteguy.com/feed/" rel="alternate" title="Learn Thai From A White Guy - Learn Thai Online &raquo; Feed" type="application/rss+xml">
	<link href="https://learnthaifromawhiteguy.com/comments/feed/" rel="alternate" title="Learn Thai From A White Guy - Learn Thai Online &raquo; Comments Feed" type="application/rss+xml">

	<!-- Stylesheets -->
	<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css?ver=4.6.1' id='membermouse-font-awesome-css' media='all' rel='stylesheet' type='text/css'>

	<link href='https://learnthaifromawhiteguy.com/wp-content/plugins/lang-quiz//css/lang-quiz.css?ver=1.0.0' id='lang-quiz-css-css' media='all' rel='stylesheet' type='text/css'>
	<link href='https://learnthaifromawhiteguy.com/wp-content/themes/news-faking-fluency/style.css?ver=5.2.1' id='news-faking-fluency-theme-css' media='all' rel='stylesheet' type='text/css'>
	<link href='https://learnthaifromawhiteguy.com/wp-includes/css/dashicons.min.css?ver=4.6.1' id='dashicons-css' media='all' rel='stylesheet' type='text/css'>
	<link href='https://learnthaifromawhiteguy.com/wp-content/plugins/bonobo/bonobo.css?ver=4.6.1' id='bonobocss-css' media='all' rel='stylesheet' type='text/css'>
	<link href='https://learnthaifromawhiteguy.com/wp-content/themes/news-faking-fluency/css/fakingfluency.css?ver=5.2.3' id='faking-fluency-style-css' media='all' rel='stylesheet' type='text/css'>
	<link href='https://learnthaifromawhiteguy.com/wp-content/themes/news-faking-fluency/js/modal.css?ver=5.2.5' rel='stylesheet' type='text/css'>

	<!-- Javascripts -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

	<link href='https://learnthaifromawhiteguy.com/wp-json/' rel='https://api.w.org/'>
	<link href="https://learnthaifromawhiteguy.com/xmlrpc.php?rsd" rel="EditURI" title="RSD" type="application/rsd+xml">
	<link href="https://learnthaifromawhiteguy.com/wp-includes/wlwmanifest.xml" rel="wlwmanifest" type="application/wlwmanifest+xml">

	<meta content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw" name="google-site-verification">
	<link href="/favicon-96x96.png" rel="icon" sizes="96x96" type="image/png">
	<link href="/favicon-16x16.png" rel="icon" sizes="16x16" type="image/png">
	<link href="/favicon-32x32.png" rel="icon" sizes="32x32" type="image/png"><!-- Android/Chrome -->
	<link href="manifest.json" rel="manifest">
	<meta content="#FFF" name="theme-color">
	<link href="/favicon-192x192.png" rel="icon" sizes="192x192" type="image/png">
	<link href="/apple-icon-57x57.png" rel="apple-icon" sizes="57x57">
	<link href="/apple-icon-114x114.png" rel="apple-icon" sizes="114x114">
	<link href="/apple-icon-72x72.png" rel="apple-icon" sizes="72x72">
	<link href="/apple-icon-144x144.png" rel="apple-icon" sizes="144x144">
	<link href="/apple-icon-60x60.png" rel="apple-icon" sizes="60x60">
	<link href="/apple-icon-120x120.png" rel="apple-icon" sizes="120x120">
	<link href="/apple-icon-76x76.png" rel="apple-icon" sizes="76x76">
	<link href="/apple-icon-152x152.png" rel="apple-icon" sizes="152x152">
	<link href="/apple-icon-180x180.png" rel="apple-icon" sizes="180x180">
	<meta content="#FFF" name="msapplication-TileColor">
	<meta content="/ms-icon-144x144.png" name="msapplication-TileImage">
	<link href='//fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=4.2.2' id='open-sans-css' media='all' rel='stylesheet' type='text/css'>
</head>
<body class="single single-lesson postid-4882 single-format-standard custom-header header-full-width content-sidebar lesson-layout">

	<div class="" id="wrap">
		<input id="lesson-title" type="hidden" value="Read Thai in 2 Weeks">
		<header class="main-header clearfix">
			<aside>
				<div class="main-option" style="float:right">
					<a href="/home"><span class="dashicons dashicons-admin-home"></span> Home</a>
				</div>
				<div class="main-option" style="float:left; padding-right: 5px">
					<a class="aside-menu" href="#"><span class="dashicons dashicons-menu"></span> <span class="dashicons dashicons-no active"></span></a>
				</div>
				<div class="menu" style="display: none">
					<ul>
						<li style="display: none"><span class="dashicons dashicons-controls-volumeon"></span> <select class="ca-select" disabled="1" style="opacity: 0.5;">
							<option value="male">
								Male
							</option>
							<option value="female">
								Female
							</option>
						</select></li>
						<li><span class="dashicons dashicons-editor-textcolor"></span> <select class="ca-font-select">
							<option value="smaller">
								Smaller
							</option>
							<option value="larger">
								Larger
							</option>
						</select></li>
					</ul>
				</div>
			</aside>
			<div class="lesson-nav">
				<div id="menu-toggle" style="float:left;" title="open navigation menu">
					<span class="dashicons dashicons-menu"></span>
				</div>
				<nav>
					<div class="nav-prev fl">
						<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/introduction/" rel="prev"><span class="meta-nav"></span> <span class="chapter first">Introduction</span></a>
					</div>
					<div class="nav-next fr">
						<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-consonants/" rel="prev"><span class="meta-nav"></span> <span class="chapter">Middle Class
						Consonants</span></a>
					</div>
				</nav>
				<div class="preferences-mobile">
					<div class="right">
						<a href="https://learnthaifromawhiteguy.com/wp-login.php?action=logout&amp;redirect_to=%2Flogout%2F&amp;_wpnonce=655eecde64"><span class=
						"dashicons dashicons-admin-plugins"></span> Logout</a>
					</div>
					<div class="left">
						<span class="dashicons dashicons-editor-textcolor"></span> <select class="ca-font-select">
							<option value="smaller">
								Smaller
							</option>
							<option value="larger">
								Larger
							</option>
						</select>
					</div>
				</div>
			</div>
		</header>
		<div id="nav">
			<div class="wrap">
				<ul class="menu genesis-nav-menu menu-primary" id="menu-primary-navigation">
					<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1385" id="menu-item-1385">
						<a href="https://learnthaifromawhiteguy.com/">Home</a>
					</li>
					<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3225" id="menu-item-3225">
						<a href="https://learnthaifromawhiteguy.com/about-brett/">About Brett</a>
					</li>
					<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3675" id="menu-item-3675">
						<a href="/learn-thai-online">Web Course</a>
					</li>
					<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-3221" id="menu-item-3221">
						<a href="https://learnthaifromawhiteguy.com/learn-thai-blog/">Blog</a>
					</li>
					<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3244" id="menu-item-3244">
						<a href="https://learnthaifromawhiteguy.com/ask-brett/">Contact Me</a>
					</li>
				</ul>
			</div>
		</div>
		<div id="inner">
			<div class="wrap">
				<div class="clearfix" id="content-sidebar-wrap">
					<div class="sidebar widget-area" id="sidebar">
						<img class="site-logo" src="https://learnthaifromawhiteguy.com/wp-content/themes/news-faking-fluency/images/brett.svg">
						<h1 class="faking-fluency"><span class="learn">Learn</span> <span class="thai">Thai</span> <span class="from-a">from a</span></h1>
						<hr>
						<h1 class="faking-fluency"><span class="white-guy">White Guy</span></h1>
						<div class="widget widget_execphp" id="execphp-4">
							<div class="widget-wrap">
								<div class="execphpwidget">
									<div style="margin-left: 2em">
										<ul>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/introduction/">Introduction</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/thai-script/">Thai Script: First Look</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-consonants/">Middle Class Consonants</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-story/">The Middle Class Story</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/say-ahhh/">Say Ahhh</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/first-vowel/">My First Vowel</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/hard-endings/">Hard Endings</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/soft-endings/">Soft Endings</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/invisible-vowels/">Invisible Vowels</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/first-tone-mark/">First Tone Mark</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/vowels-so-many-vowels/">Vowels, So Many Vowels</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-second-tone-mark/">The Second Tone Mark</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/vocabulary-1/">Vocabulary 1</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-long-and-short-of-it/">The Long and Short of It</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-letters-%e0%b8%a7-and-%e0%b8%a2/">Low Class Letters: ว and ย</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-placeholder/">อ &#8211; The Placeholder</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-sounds-of-silence/">The Sounds of Silence</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-tone-rules/">Middle Class Tone Rules</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/quiz-1/">Quiz 1A</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/quiz-1b/">Quiz 1B</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/high-class-consonants/">High Class Consonants</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/high-class-tone-rules/">High Class Tone Rules</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/gurgling-vowels/">Gurgling Vowels</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/complex-vowels/">Complex Vowels</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/enjoy-the-silence/">Enjoy the Silence</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/ive-got-your-num-%e0%b9%80%e0%b8%9a%e0%b8%ad%e0%b8%a3%e0%b9%8c/">I&#8217;ve got your num-เบอร์</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/getting-more-complex/">Getting More Complex</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/numbers/">Numbers</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/number-quiz-1-10/">Number Quiz (1-10)</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-shortener/">The Shortener</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/strange-endings/">Strange Endings</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-killer/">The Killer</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-falling/">Low Class Part 1: Falling Tones</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/vocabulary-2/">Vocabulary 2</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-%e0%b8%93-%e0%b8%98-%e0%b8%a0-%e0%b8%8d/">Low Class: ณ ธ ภ ญ ฮ</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-with-tone-marks/">Low Class with Tone Marks</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-with-hard-endings/">Low Class with Hard Endings</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-practice/">Low Class Practice</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/inherent-vowels/">Inherent Vowels</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/crazy-spellings/">Crazy Spellings</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/3rd-and-4th-tone-marks/">3rd and 4th Tone Marks</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/the-rest-of-it/">The Rest of It</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/what-now/">What Now?</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/how-to-practice-tones/">How to Practice Tones</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/tone-rules-mind-map/">Tone Rules Mind Map</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-drills/">Middle Class Drills</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/high-class-drills/">High Class Drills</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/mid-and-high-class-drills/">Mid and High Class Drills</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/low-class-drills/">Low Class Drills</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/all-class-drills/">All Class Drills</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/number-drills/">Number Drills</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/simple-sentence-structure/">Simple Sentence Structure</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/thai-colors/">Thai Colors</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/learn-thai-days-week/">Learn Thai Days of the Week</a>
											</li>
											<li>
												<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/learn-thai-months/">Thai Months</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="hfeed" id="content">
						<div class="lesson">
							<div class="lesson-nav-but lesson-nav-top cf">
								<div class="prev-but">
									<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/introduction/" title="Introduction">&lt;&lt; Introduction</a>
								</div>
								<div class="reportsound">
									<a href="mailto:brett@learnthaifromawhiteguy.com">Report a dead sound</a>
								</div>
								<div class="next-but">
									<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-consonants/" title="Middle Class Consonants">Middle Class Consonants &gt;&gt;</a>
								</div>
							</div>
							<h1>Thai Script: First Look</h1>
							<p>Learning to read Thai is the most important step you will be taking on your journey to learn Thai. This course is going to attempt to help familiarise you with how the
							Thai script works and give you actual examples of very common words and phrases even before you know how to read. This will be especially useful for people who are
							skeptical about learning to read. It does generally take a couple weeks to get the system into your head and a month or 2 to master, but the payoff will be enormous and
							you&#8217;ll understand within a couple hours why you need to know this.</p>
							<p>Let’s start with Thai people’s favorite activity and a word you’ll hear every day no matter what part of the country you find yourself in:</p>
							<p>Thai <audio id="กิน" preload="auto" src="/speech/%E0%B8%81%E0%B8%B4%E0%B8%99.mp3"></audio><a class="speech" onclick=
							"document.getElementById('กิน').play()">กิน<span class="dashicons dashicons-controls-volumeon"></span></a><br>
							English: to eat<br>
							Breakdown: These 3 parts combine to make one syllable. Initial Consonant + Vowel + Final Consonant</p>
							<ul>
								<li>
									<audio id="ก" preload="auto" src="/speech/%E0%B8%81.mp3"></audio><a class="speech" onclick="document.getElementById('ก').play()">ก<span class=
									"dashicons dashicons-controls-volumeon"></span></a>
								</li>
								<li>
									<audio id="อิ" preload="auto" src="/speech/%E0%B8%AD%E0%B8%B4.mp3"></audio><a class="speech" onclick="document.getElementById('อิ').play()">อิ<span class=
									"dashicons dashicons-controls-volumeon"></span></a> *The vowel is the shape above the basin letter (อ). Vowels are never written alone and must always be attached to a
									consonant.
								</li>
								<li>
									<audio id="น" preload="auto" src="/speech/%E0%B8%99.mp3"></audio><a class="speech" onclick="document.getElementById('น').play()">น<span class=
									"dashicons dashicons-controls-volumeon"></span></a>
								</li>
							</ul>
							<p>Notice how we attach an &#8220;aww&#8221; vowel after each of the consonant sounds. This happens for every letter.</p>
							<p>There are 3 pieces to this puzzle. An initial consonant, a vowel and a final consonant. The vowel is actually the shape above the letter in # 2. In Thai, you will never
							write a vowel shape by itself. It will always be attached to a letter. In the case of the above example, the vowel happens to appear on top of the letter it&#8217;s being
							attached to. This will not always be the case and the position of the vowel does not affect its pronunciation.</p>
							<p>The chicken letter, <audio id="ก" preload="auto" src="/speech/%E0%B8%81.mp3"></audio><a class="speech" onclick="document.getElementById('ก').play()">ก<span class=
							"dashicons dashicons-controls-volumeon"></span></a> is like a [k] sound, but be careful as it isn’t aspirated like most “k” sounds are in English. Aspirated consonants have
							a strong blast of air that comes out of your mouth when you pronounce them. Put your hand in front of your mouth and say the following words:</p>
							<ul>
								<li>car</li>
								<li>can</li>
								<li>cool</li>
								<li>back</li>
								<li>deck</li>
							</ul>
							<p>You should have a felt a strong puff of air from the first 3 words and the same from the ending consonant of the final letter. In Thai, the chicken letter <audio id="ก"
							preload="auto" src="/speech/%E0%B8%81.mp3"></audio><a class="speech" onclick="document.getElementById('ก').play()">ก<span class=
							"dashicons dashicons-controls-volumeon"></span></a> does not have that strong blast of air. Try saying the a “k” very softly and see if you can stop yourself from sending
							out the puff of air. Remember to keep your hand in front of your mouth so you can feel the difference. If you feel a strong blast, you are saying it wrong and probably
							won’t be understood. It may sound like a “g,” but it’s not quite the same and it’s better not to think of it this way. This stuff is more important than the tones so don’t
							neglect practicing it. Read this more than once.</p>
							<p>The อ letter you will see in all the following examples is a special placeholder that has no consonant sound value attached to it. Think of Thai vowel shapes as clothing
							for consonants. The consonants wear different vowels which give us different sound combinations.</p>
							<p>Think about how we say the alphabet in English:</p>
							<ul>
								<li>B [bee]</li>
								<li>C [see]</li>
								<li>D [dee]</li>
								<li>E [eee]</li>
							</ul>
							<p>When I say vowels are like clothing, think about the 4 letters above as all “wearing” an “eee” vowel. If you can wrap your head around that, you’re on the right
							track.</p>
							<p>Not all letters take that [eee] vowel sound as that would severely limit the amount of words you could come up with, but hopefully you get the idea. In Thai, we always
							add an <audio id="ออ" preload="auto" src="/speech/%E0%B8%AD%E0%B8%AD.mp3"></audio><a class="speech" onclick="document.getElementById('ออ').play()">ออ<span class=
							"dashicons dashicons-controls-volumeon"></span></a> vowel sound [aww] to a consonant when we are referring to it. This is generally called an “inherent vowel,” meaning that
							if there is no other vowel written, we will use the <audio id="ออ" preload="auto" src="/speech/%E0%B8%AD%E0%B8%AD.mp3"></audio><a class="speech" onclick=
							"document.getElementById('ออ').play()">ออ<span class="dashicons dashicons-controls-volumeon"></span></a> sound.</p>
							<p>Thai words and syllables are generally made up of 2-3 parts. However, some vowel shapes will have multiple parts to them. It&#8217;s different and may seem a bit weird
							at times, but when you are a couple of hours into this course, everything should start to click and you will see how important learning this stuff really is.</p>
							<p>Ready to get started? Move on to the first real lesson and get to work!</p>

							<div class="buy-box"><h4>Start Speaking Thai Today!</h4><div class="body"><div><p>The best way to learn Thai.<br>Buy now and get <strong>$50 off!</strong></p><div><div class="old-price">$147</div><div class="new-price">$97</div></div></div><a href="/checkout"><img src="/wp-content/themes/news-faking-fluency/images/products/read_thai_in_2_weeks.jpg" alt="Read Thai in 2 Weeks" width="150" height="auto"></a></div><div class="footer"><a class="btn" href="/checkout">Instant Access!</a></div></div>


						</div>
						<div class="lesson-nav post-entries">
							<nav>
								<div class="nav-prev fl">
									<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/introduction/" rel="prev"><span class="meta-nav"></span> <span class="chapter">Introduction</span></a>
								</div>
								<div class="nav-next fr">
									<a class="ff-modal" data-dialog-id="preview-checkout-dialog" href="https://learnthaifromawhiteguy.com/lesson/middle-class-consonants/" rel="prev"><span class="meta-nav"></span> <span class="chapter">Middle Class
									Consonants</span></a>
								</div>
							</nav>
						</div>
					</div><!-- end #content -->
				</div><!-- end #content-sidebar-wrap -->
			</div>
		</div>
		<div class="footer" id="footer">
			<div class="wrap">
				<div class="gototop">
					<p><a href="#wrap" rel="nofollow">Return to top of page</a></p>
				</div>
				<div class="creds">
					<p>Copyright &#x000A9;&nbsp;2017 Learn Thai From A White Guy</p>
				</div>
			</div>
		</div>
	</div>
	<script src='https://learnthaifromawhiteguy.com/wp-content/plugins/clickable-audio//js/speech.js?ver=5.1.0'></script>
	<script src='https://learnthaifromawhiteguy.com/wp-content/plugins/lang-quiz//js/lang-quiz.js?ver=1.0.0'></script>
	<script src='https://learnthaifromawhiteguy.com/wp-includes/js/comment-reply.min.js?ver=4.6.1'></script>
	<script src='https://learnthaifromawhiteguy.com/wp-content/themes/news-faking-fluency/js/fakingfluency.js?ver=5.1.0'></script>
	<script src='https://learnthaifromawhiteguy.com/wp-content/themes/news-faking-fluency/js/modal.es5.js?ver=5.1.3'></script>
	<script src='https://learnthaifromawhiteguy.com/wp-includes/js/wp-embed.min.js?ver=4.6.1'></script>
	<style>
	a.new-stripe-button {
		display: inline-block;
		min-width: 200px;
		color: #fff !important;
		font-size: 26px;
		line-height: 28px;
		border-radius: 3px;
		margin: 0 auto;
		padding: 8px 10px 10px 10px;
		border-bottom: none !important;
		text-decoration: none !important;

		text-align: center;
		box-sizing: border-box;

		background: #009c0a;
		background: #28b1de;
		margin-top: 25px;
	}
	</style>
	<dialog id="preview-checkout-dialog">
		<div style="text-align: center">
			<h2>Thanks for trying out the free Thai lessons.</h2>
			<p>Purchase access to the rest of the full 50+ lesson course by clicking below</p>
			<p>
				<a class="new-stripe-button" href="/checkout">Buy Now</a>
			</p>
			<p>
				<a href="#" class="ff-modal-close">close</a>
		</div>
	</dialog>
</body>
</html>
