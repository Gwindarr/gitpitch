<?php require_once ('wp-config.php');
#require_once("wp-content/plugins/membermouse/includes/mm-constants.php");
#require_once("wp-content/plugins/membermouse/includes/init.php");
require_once('phpab.php');


	$subtitle_text = new phpab('subtitle_text');
	$subtitle_text->add_variation('best_course');
	$subtitle_text->set_ga_slot('7');
	
	if ($subtitle_text->get_user_segment()=='best_course') {
		$subtitle = 'The Best Thai Course on the Web';
	} else {
		$subtitle = 'The Fastest Way to Learn Thai, Guaranteed!';
	}

?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title>Free Online Thai Lesson - Learn Thai From A White Guy</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="canonical" href="https://learnthaifromawhiteguy.com/free-thai-lesson">
  <meta property="og:locale" content="en_US">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:url" content="https://learnthaifromawhiteguy.com/free-thai-lesson">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="fb:admins" content="689928716">
  <link rel="stylesheet" href="/wp-content/themes/news/style.css?ver=2.0.1" type="text/css" media="all">
  <script type="text/javascript" src="/wp-includes/js/jquery/jquery.js?ver=1.10.2"></script>
  <meta name="google-site-verification" content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw">
  <meta name="Description" content="The Best Thai Course on the web!">
  <link href="https://fonts.googleapis.com/css?family=Sniglet" rel="stylesheet" type="text/css">

	<link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96">
	<link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
	<link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">

	<!-- Android/Chrome -->
	<link rel="manifest" href="manifest.json">
	<meta name="theme-color" content="#FFF">
	<link rel="icon" type="image/png" href="/favicon-192x192.png" sizes="192x192">
	<link rel="apple-icon" sizes="57x57" href="/apple-icon-57x57.png">
	<link rel="apple-icon" sizes="114x114" href="/apple-icon-114x114.png">
	<link rel="apple-icon" sizes="72x72" href="/apple-icon-72x72.png">
	<link rel="apple-icon" sizes="144x144" href="/apple-icon-144x144.png">
	<link rel="apple-icon" sizes="60x60" href="/apple-icon-60x60.png">
	<link rel="apple-icon" sizes="120x120" href="/apple-icon-120x120.png">
	<link rel="apple-icon" sizes="76x76" href="/apple-icon-76x76.png">
	<link rel="apple-icon" sizes="152x152" href="/apple-icon-152x152.png">
	<link rel="apple-icon" sizes="180x180" href="/apple-icon-180x180.png">


	<meta name="msapplication-TileColor" content="#FFF">
	<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">  
</head>
<body class="optin-page custom-header content-sidebar news">
	
	<?php include 'wp-content/themes/news-faking-fluency/_analytics.php'; ?>

	<div id="wrap">
		<div id="header">
      <div class="wrap">
        <div id="title-area">
          <h1 id="title">
						<a href="https://learnthaifromawhiteguy.com" title="Learn Thai from a White Guy">
							<img title="Learn Thai from a White Guy" src="/wp-content/themes/news/images/header.png" 
								data-sumome-listbuilder-id="610c4597-ecb3-4a56-8525-cfa507ccb8f8">
						</a>
					</h1>
          <div class="head-right">
            <div class="subtitle wrap">
							<h2><?php echo $subtitle; ?></h2>
						</div>
          </div>
        </div>
      </div>
    </div>

    <div id="inner" class="nobg">
      <div class="wrap">
        <div id="content-sidebar-wrap">
					<div class="optin">
						<h1 class="entry-title">Free Online Thai Lesson</h1> 
							<div class="entry-content">
								<img style="float: right; margin-left: 15px;" src="/wp-content/themes/news/images/productimage-easy.jpg">
								<div class="optin-form foist">
									<p>Enter your email to get the first lesson of my web course and start learning Thai right now!</p>
									<p class="small">I'll also send you updates and more free stuff to help you improve your Thai.</p>
									<form method="post" action="https://www.aweber.com/scripts/addlead.pl" accept-charset="utf-8">
										<input type="hidden" name="listname" value="free_optin" />
										<input type="hidden" name="meta_forward_vars" value="0" />
										<input type="hidden" name="meta_message" value="1" /> 
										<input type="hidden" name="meta_required" value="email" />
										<input type="hidden" name="meta_adtracking" value="free_thai_lesson_form"> 
										<input type="hidden" name="redirect" value="https://learnthaifromawhiteguy.com/confirm-signup?ref=freethailesson_page&utm_nooverride=1" />
										<input type="text" placeholder="Email Address" name="email"><br>
										<input type="submit" name="submit" value="Get Lesson"><br>
									</form>
									<p class="privacy"><a href="/privacy-policy" target="_blank">Privacy Policy</a></p>
								</div>
								<div class="below-optin">
								<ul>
									<li>
										<h3>Easily pronounce words and tones correctly</h3>
										<p>My system will get you solid on the sounds and tones of Thai in no time. Once you study with my 
										method, it'll all come naturally.</p>
									</li>
									<li>
										<h3>Thai people will understand you every time</h3>
										<p>Do Thai people look at you funny when you try to speak Thai to them? Do they think you're speaking 
										English and don't understand? That won't happen after you take my course.</p>
									</li>
									<li>
										<h3>Master the alphabet and read everything</h3>
										<p>My method simplifies learning the alphabet so you'll be a master in no time. Easily read signs 
										and menus and decode the world around you.</p>
									</li>
								</ul>
								<div class="optin-form secondary second">
									<h4>Try the first lesson free!</h4>
									<form method="post" action="https://www.aweber.com/scripts/addlead.pl" accept-charset="utf-8">
										<input type="hidden" name="listname" value="free_optin" />
										<input type="hidden" name="meta_forward_vars" value="0" />
										<input type="hidden" name="meta_message" value="1" /> 
										<input type="hidden" name="meta_required" value="email" />
										<input type="hidden" name="meta_adtracking" value="optinpage_optin_form">  
										<input type="hidden" name="redirect" value="https://learnthaifromawhiteguy.com/confirm-signup?ref=freethailesson_page&utm_nooverride=1" />
										<input type="text" placeholder="Email Address" name="email"><br>
										<input type="submit" name="submit" value="Get Lesson"><br>
									</form>
								</div>
								<div class="testimonial cf">
									<img src="/wp-content/themes/news/images/quote-travis.jpg">
									"I've been studying with Brett for 2 months and <b>I'm blown away by the progress I've made</b>. I can 
									read anything in Thai, understand the tone and properly pronounce it. After learning how to read, he 
									started teaching me practical vocabulary, sentence structure and how to speak like a Thai (which is 
									way different than what most language books will teach you, of course). I live in Thailand and my 
									experience here has drastically improved since studying with Brett. I've been sending fellow expats 
									his way ever since my first lesson - this guy knows what he's doing."
									<p class="attrib">- Travis from USA</p>
								</div>
								
								<div class="testimonial cf">
									<img src="/wp-content/themes/news/images/quote-john.jpg">
									"<b>In 3 hours, I'd pummeled the thai alphabet into my head</b>. All those squiggly lines and curly 
									characters? I know 'em. It's been a smooth ride ever since. 3 months down the road and I can read 
									pretty much everything (and understand a helluva lot more of what's going on around me). This makes 
									living in Thailand a blast. Also, when I hear other foreigners speaking Thai who haven't learned the 
									alphabet, they sound ridiculous and nothing like the way they should sound." 
									<p class="attrib">- John from Australia</p>
								</div>
								
								<div class="testimonial cf">
									<img src="/wp-content/themes/news/images/quote-matt.jpg">
									"Been studying with the white guy for almost a year now, that should tell its own story. <b>You really 
									do get the alphabet cracked in a matter of hours!!</b> Brett's ability to unravel the mystery has 
									really opened up a lot of doors for me. Every lesson I'm learning new material, on stuff I want to 
									learn about. I feel so confident holding conversations knowing the language I'm using is the real 
									deal!! No more over-polite robot speech!! This confidence combined with a no-pressure learning 
									environment is what keeps me coming back for more!!" 
									<p class="attrib">- Matt from UK</p>
								</div>
								
								<div class="optin-form secondary third">
									<h4>Try the first lesson free!</h4>
									<form method="post" action="https://www.aweber.com/scripts/addlead.pl" accept-charset="utf-8">
										<input type="hidden" name="listname" value="free_optin" />
										<input type="hidden" name="meta_forward_vars" value="0" />
										<input type="hidden" name="meta_message" value="1" /> 
										<input type="hidden" name="meta_required" value="email" /> 
										<input type="hidden" name="meta_adtracking" value="optinpage_optin_form"> 				
										<input type="hidden" name="redirect" value="https://learnthaifromawhiteguy.com/confirm-signup?ref=freethailesson_page&utm_nooverride=1" />
										<input type="text" placeholder="Email Address" name="email"><br>
										<input type="submit" name="submit" value="Get Lesson"><br>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</html>