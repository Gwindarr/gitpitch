<?php
echo 'ok';
/*require_once("mixpanel-php/lib/Mixpanel.php");
require_once("universal-analytics.php");

$first_name = $_GET["first_name"];
$last_name = $_GET["last_name"];
$email = $_GET["email"];
$member_id = $_GET["member_id"];
$order_number = $_GET["order_number"];
$total = $_GET["order_total"];
$discount = $_GET["order_discount"];
$affiliate = $_GET["order_affiliate_id"];
$member_date = $_GET["registered"];
$billingAddress = $_GET["billing_address"];

if (!empty($billingAddress)) {
	$pay_method = 'stripe';
} else {
	$pay_method = 'paypal';
}

	$mp->people->set($member_id, array(
    '$first_name'       => $first_name,
    '$last_name'        => $last_name,
    '$email'            => $email,
    '$created'          => $member_date,
		'payment method'    => $pay_method,
		'discount'          => $discount
	));

	
	$mp->track('mmcallbacksale', array(
	'amount' => $order_total,
	'name' => $first_name,
	'email' => $email,
	'order number' => $order_number,
	'payment method' => 'stripe'
	));

	$mp->people->trackCharge($member_id, $order_total, strtotime($member_date));*/

?>