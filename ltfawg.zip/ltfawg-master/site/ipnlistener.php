<?php
require_once("mixpanel-php/lib/Mixpanel.php");
require_once("universal-analytics.php");
$mp = Mixpanel::getInstance(" 39419bbad75e3856efc5599fe74b3617 ");



// stripe
Stripe::setApiKey("sk_test_8LORCMMz3eJwMMVbJ5pjSVMp");
$body = @file_get_contents('php://input');
$event = json_decode($body);

$stripe_amount = $event->amount;
$stripe_receiptid = $event->id;
$stripe_name = $event->name;
$stripe_email = $event->email;
$stripe_nameexplode = explode(" ", $stripe_name);
$stripe_fname = $name[0];
$stripe_lname = $name[1];


if ($event->type == 'charge.succeeded') {
	$mp->track('stripeapitest', array(
	'amount' => $stripeamount,
	'name' => $stripe_name,
	'email' => $email,
	'receiptid' => $stripe_receiptid,
	'paymethod' => 'stripe'
	));
}

// paypal
$customerid = $_POST['payer_id'];
$transid = $_POST['receipt_id'];
$fname = $_POST['first_name'];
$lname = $_POST['last_name'];
$purchasedate = $_POST['payment_date'];
$email = $_POST['payer_email'];
$amount = $_POST['mc_gross'];
if (!empty($amount)) {
$mp->track("Sale", array(
	'amount' => $amount,
	'name' => $fname.' '.$lname,
	'email' => $email,
	'receiptid' => $transid,
	'paymethod' => 'paypal'
));

$mp->people->set($customerid, array(
    '$first_name'       => $fname,
    '$last_name'        => $lname,
    '$email'            => $email,
		'$created' => $purchasedate
));

$mp->people->trackCharge($customerid, $amount, strtotime($purchasedate));
}

// mixpanel getresponse

$graction = $_POST['action'];
$gremail = $_POST['contact_email'];
$grid = $_POST['CONTACT_ID'];

if (!empty($graction)) {
$mp = Mixpanel::getInstance(" 39419bbad75e3856efc5599fe74b3617 ");

$mp->track("Optin IPN", array( "email" => $gremail ));

$mp->people->set($customerid, array(
    '$email' => $gremail,
		"ID" => $grid
));
}

?>




<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
