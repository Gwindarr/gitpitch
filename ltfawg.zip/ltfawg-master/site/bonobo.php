<?php
/**
 * Plugin Name: Bonobo
 * Plugin URI: http://learnthaifromawhiteguy.com
 * Description: Adds flashcard functionality to posts.
 * Version: 0.1b
 * Author: Raus Taburk
 */
 
global $post;
wp_enqueue_script('bonobojs', WP_PLUGIN_URL.'/bonobo.js', array('jquery'));
wp_enqueue_style('bonobocss', WP_PLUGIN_URL.'/bonobo.css');
 
add_action( 'load-post.php', 'bonobo_setup' );
add_action( 'load-post-new.php', 'bonobo_setup' );
 
function bonobo_setup() {
	add_action( 'add_meta_boxes', 'bonobo_add_field' );
	add_action( 'save_post', 'bonobo_save_field', 10, 2 );
	update_post_meta($post->ID, 'Bonobo', '', true);
}

function bonobo_add_field() {
	add_meta_box('bonobo-field', 'Bonobo Flashcards', 'bonobo_display_field', 'post');
}
?>
<?php function bonobo_display_field($object,$field) { ?>
	<?php wp_nonce_field( basename( __FILE__ ), 'bonobo_nonce' ); ?>
	<p>
		<label for="bonobo_cards"><?php _e( "Add in flashcards, one per line, front and back separated by a comma (ปลา,fish). Spaces will be treated as flashcard content.", 'example' ); ?></label>
    <br />
    <input class="widefat" type="textarea" name="bonobo_cards" id="bonobo_cards" value="<?php echo esc_attr( get_post_meta( $object->ID, 'bonobo_cards', true ) ); ?>" />
  </p>
<?php } ?>

<?php
function bonobo_save_field() {
	if (!isset( $_POST['bonobo_nonce']) || !wp_verify_nonce($_POST['bonobo_nonce'], basename( __FILE__ ))) {
		return $post_id;
	}
	
	$post_type = get_post_type_object( $post->post_type );
	
	 if (!current_user_can($post_type->cap->edit_post, $post_id )) {
    return $post_id;
	}
	
	$new_meta_value = ( isset( $_POST['bonobo_cards'] ) ? sanitize_html_class( $_POST['bonobo_cards'] ) : '' );

  /* Get the meta key. */
  $meta_key = 'bonobo_cards';

  /* Get the meta value of the custom field key. */
  $meta_value = get_post_meta( $post_id, $meta_key, true );

  /* If a new meta value was added and there was no previous value, add it. */
  if ( $new_meta_value && '' == $meta_value )
    add_post_meta( $post_id, $meta_key, $new_meta_value, true );

  /* If the new meta value does not match the old value, update it. */
  elseif ( $new_meta_value && $new_meta_value != $meta_value )
    update_post_meta( $post_id, $meta_key, $new_meta_value );

  /* If there is no new meta value but an old value exists, delete it. */
  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );
}






function bonobo_get_cards() {
	$post_id = get_the_ID();
	if ( !empty( $post_id ) ) {
		$bonobo_cards_meta = get_post_meta( $post_id, 'bonobo_cards', true );
		return $bonobo_cards_meta;
	}
}

// shortcode
add_shortcode('bonobo','bonobo_cards');

function bonobo_cards() {
	
}

?>


	
