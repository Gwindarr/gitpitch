<?php setcookie("oto"); ?>

<html>
<head>
<title>blah</title>
</head>
<body>

<?php if (isset($_COOKIE["oto"])) : ?>
cookie
<?php else : ?>
no cookie
<?php endif; ?>


</body>



</html>






