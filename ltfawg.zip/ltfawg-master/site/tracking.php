<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new 
Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-16669378-1', 'auto', {'allowLinker': true});
	ga('require', 'ecommerce');
	ga('require', 'displayfeatures');
	ga('require', 'linkid', 'linkid.js');
        ga('require', 'linker');
	ga('linker:autoLink', ['dpdcart.com']);
	
	<?php /*
		<?php /* if (!empty($_COOKIE['phpab-price_test'])) : ?>
			<?php if ($_COOKIE['phpab-price_test'] == '147') : ?>
				ga('set', 'dimension2', '147 post test');
			<?php endif; ?>
		<?php endif; ?>
	*/ ?>
		<?php if (!empty($subtitle_text)) : ?>
			<?php if ($subtitle_text->get_user_segment()=='best_course') : ?>
				ga('set', 'dimension7', 'best thai course on the web');
			<?php else : ?>
				ga('set', 'dimension7', 'fastest way');
			<?php endif; ?> 
		<?php endif; ?> 
	
	
	ga(function(tracker) {
		var clientId = tracker.get('clientId');
		ga('set', 'dimension4', clientId);
	});
	
// Optimizely Universal Analytics Integration Code
window.optimizely = window.optimizely || [];
window.optimizely.push("activateUniversalAnalytics");
// End Optimizely Code
	
  ga('send', 'pageview');
</script>

<!-- start Mixpanel -->
<script type="text/javascript">(function(e,b){if(!b.__SV){var a,f,i,g;window.mixpanel=b;a=e.createElement("script");a.type="text/javascript";a.async=!0;a.src=("https:"===e.location.protocol?"https:":"http:")+'//cdn.mxpnl.com/libs/mixpanel-2.2.min.js';f=e.getElementsByTagName("script")[0];f.parentNode.insertBefore(a,f);b._i=[];b.init=function(a,e,d){function f(b,h){var a=h.split(".");2==a.length&&(b=b[a[0]],h=a[1]);b[h]=function(){b.push([h].concat(Array.prototype.slice.call(arguments,0)))}}var c=b;"undefined"!==
typeof d?c=b[d]=[]:d="mixpanel";c.people=c.people||[];c.toString=function(b){var a="mixpanel";"mixpanel"!==d&&(a+="."+d);b||(a+=" (stub)");return a};c.people.toString=function(){return c.toString(1)+".people (stub)"};i="disable track track_pageview track_links track_forms register register_once alias unregister identify name_tag set_config people.set people.set_once people.increment people.append people.track_charge people.clear_charges people.delete_user".split(" ");for(g=0;g<i.length;g++)f(c,i[g]);
b._i.push([a,e,d])};b.__SV=1.2}})(document,window.mixpanel||[]);
mixpanel.init("39419bbad75e3856efc5599fe74b3617");</script>
<!-- end Mixpanel -->

<!-- FB retargetting -->
<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '889491824415946']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=889491824415946&amp;ev=PixelInitialized" /></noscript>
