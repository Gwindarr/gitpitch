<?php header('Content-type: text/html; charset=utf-8'); 

 require_once ('wp-config.php');
require_once("wp-content/plugins/membermouse/includes/mm-constants.php");
require_once("wp-content/plugins/membermouse/includes/init.php");
require_once("phpab.php"); 
require_once("mixpanel-php/lib/Mixpanel.php"); 
$mp = Mixpanel::getInstance("39419bbad75e3856efc5599fe74b3617"); // instantiate the Mixpanel class
$optin_image = new phpab('optin_image');
$optin_image->add_variation('pointing');


/*
require_once("phpab.php"); 
if($optin_image->get_user_segment() == 'pointing') {
		$mp->track("Optin Page Visit", array("variation" => "pointing"));
	} else {
		
	}
	*/
$mp->track("optin");
	
	$email=$_POST['email'];
	
	?>
	<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" prefix="og: http://ogp.me/ns#">
<head>
  <meta http-equiv="Content-Type" content="text/html">
	<meta charset="ISO-8859-1">
  <title>Your First Lesson - Learn Thai From A White Guy</title>
  <link rel="Shortcut Icon" href="/wp-content/uploads/2012/08/favicon.ico" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- This site is optimized with the Yoast WordPress SEO plugin v1.4.13 - http://yoast.com/wordpress/seo/ -->
  <link rel="canonical" href="http://learnthaifromawhiteguy.com/">
  <style type="text/css"></style><meta property="og:locale" content="en_US">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com/">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="fb:admins" content="689928716"><!-- / Yoast WordPress SEO plugin. -->
  <link rel="alternate" type="application/rss+xml" title="Learn Thai From A White Guy ? Feed" href="http://learnthaifromawhiteguy.com/feed/">
 
  <link rel="stylesheet" id="news-theme-css" href="/wp-content/themes/news/style.css?ver=2.0.0" type="text/css" media="all">
<script type="text/javascript" src="/wp-includes/js/jquery/jquery.js?ver=1.10.2">
</script><style type="text/css"></style><style type="text/css"></style>
  <script type="text/javascript" src="/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1">
</script>

  <!-- Open Graph Meta Data by WP-Open-Graph plugin-->
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="og:locale" content="en_us">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com">
  <meta property="og:description" content="Yes, Really">
  <meta property="fb:admins" content="689928716"><!-- /Open Graph Meta Data -->
  <link rel="Shortcut Icon" href="http://learnthaifromawhiteguy.com/wp-content/themes/news/images/favicon.ico" type="image/x-icon">
  <link rel="pingback" href="http://learnthaifromawhiteguy.com/xmlrpc.php">
  <meta name="google-site-verification" content="QfX2hYT5L3fjeu4iFdF1eBLDJ-KND7-axydYpjK4BYw">
  <!-- WordPress Facebook Open Graph protocol plugin (WPFBOGP v2.0.7) http://rynoweb.com/wordpress-plugins/ -->
  <meta property="fb:admins" content="689928716">
  <meta property="og:url" content="http://learnthaifromawhiteguy.com">
  <meta property="og:title" content="Learn Thai From A White Guy">
  <meta property="og:site_name" content="Learn Thai From A White Guy">
  <meta property="og:description" content="">
  <meta property="og:type" content="website">
  <meta property="og:image" content="http://learnthaifromawhiteguy.com/wp-content/uploads/2011/03/all-consonants-150x150.png">
  <meta property="og:locale" content="en_us">


  <meta name="Description" content="The Best Thai Course on the web!">
  <link href="https://fonts.googleapis.com/css?family=Sniglet" rel="stylesheet" type="text/css">

<?php require_once("tracking.php"); ?>
<?php if (!empty($email)) : ?>
		<?php
	// $mp->track("First Lesson Visit");
	require_once("universal-analytics.php");
	$t = new Tracker( 'UA-16669378-1', '815835312344-smsfo23t54qg83gg8n269diq376nurcu.apps.googleusercontent.com', null);
	
	$email=$_POST['email'];
	$mp->people->set(mt_rand(10000,99999), array( '$name' => $email, '$email' => $email ));
	$mp->identify($grid);
	$mp->track("optin");
	if (!empty($email)) {
		$t->send( 'event', array(
			'eventCategory' => 'conversion',
			'eventAction' => 'optin',
		));
	}
?>
<!-- adwords -->
		<script type="text/javascript">
		/* <![CDATA[ */
		var google_conversion_id = 1015124111;
		var google_conversion_language = "en";
		var google_conversion_format = "3";
		var google_conversion_color = "ffffff";
		var google_conversion_label = "SlKFCKHa8wgQj6GG5AM";
		var google_conversion_value = 0;
		var google_remarketing_only = false;
		/* ]]> */
		</script>
		<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
		</script>
		<noscript>
		<div style="display:inline;">
		<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1015124111/?value=0&amp;label=SlKFCKHa8wgQj6GG5AM&amp;guid=ON&amp;script=0"/>
		</div>
		</noscript>		
		<!-- fb conversion -->
		<script type="text/javascript">
		var fb_param = {};
		fb_param.pixel_id = '6011801059278';
		fb_param.value = '0.00';
		fb_param.currency = 'USD';
		(function(){
			var fpw = document.createElement('script');
			fpw.async = true;
			fpw.src = '//connect.facebook.net/en_US/fp.js';
			var ref = document.getElementsByTagName('script')[0];
			ref.parentNode.insertBefore(fpw, ref);
		})();
		</script>
		<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6011801059278&amp;value=0&amp;currency=USD" /></noscript>
	
<?php endif; ?>

<!-- Google Analytics Tracking-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-16669378-1', 'auto');
  ga('send', 'pageview');

</script>
</head>

<body class="optin-page custom-header content-sidebar news">
  <div id="wrap">


    <div id="header">
      <div class="wrap">
        <div id="title-area">
          <h1 id="title"><a href="http://learnthaifromawhiteguy.com" title="Learn Thai from a White Guy"><img title="Learn Thai from a White Guy" src="/wp-content/themes/news/images/header.png"></a></h1>

          <div class="head-right">
            <h2>The Best Thai Course on the Web!</h2>
          </div>
        </div>
      </div>
    </div>


    <div id="inner" class="nobg">
      <div class="wrap">
        <div id="content-sidebar-wrap">
				
<div class="optin">
	<h1 class="entry-title">Your First Lesson</h1> 
	<div class="entry-content"><p>Welcome to your first Thai lesson! We’re going to start with learning to read. If you know the Thai alphabet and understand how it works, you’ll also understand the sounds and tones of the language. We’re going to start with the first three letters, <audio id="ด" src="/speech/%E0%B8%94.mp3" preload="auto"></audio><a onclick="document.getElementById('ด').play()" class="speech">ด</a>, <audio id="ก" src="/speech/%E0%B8%81.mp3" preload="auto"></audio><a onclick="document.getElementById('ก').play()" class="speech">ก</a> and <audio id="ป" src="/speech/%E0%B8%9B.mp3" preload="auto"></audio><a onclick="document.getElementById('ป').play()" class="speech">ป</a>. Click them to hear the sound.</p>
<p>Every letter in the Thai alphabet has a name. As this course is written with the complete beginner in mind, we are going to use the English translation of the names of the letters to give us our first memory hook. Click on the letters to hear their names if you’d like, but don’t worry too much about what’s going on there just yet. We’ll get to that in a moment. &nbsp;For now, you just focus on the names of the letters.</p>
<p><audio id="ด" src="/speech/%E0%B8%94.mp3" preload="auto"></audio><a onclick="document.getElementById('ด').play()" class="speech">ด</a> – kid; child&nbsp;(<audio id="เด็ก" src="/speech/%E0%B9%80%E0%B8%94%E0%B9%87%E0%B8%81.mp3" preload="auto"></audio><a onclick="document.getElementById('เด็ก').play()" class="speech">เด็ก</a>)<br>
<strong>mnemonic:</strong>&nbsp;A kid in a white-sheet ghost costume, but with only 1 eye hole</p>
<p><audio id="ก" src="/speech/%E0%B8%81.mp3" preload="auto"></audio><a onclick="document.getElementById('ก').play()" class="speech">ก</a> – chicken&nbsp;(<audio id="ไก่" src="/speech/%E0%B9%84%E0%B8%81%E0%B9%88.mp3" preload="auto"></audio><a onclick="document.getElementById('ไก่').play()" class="speech">ไก่</a>)<br>
<strong>mnemonic:</strong>&nbsp;This one’s easy. It looks like the head of a bird!</p>
<p><audio id="ป" src="/speech/%E0%B8%9B.mp3" preload="auto"></audio><a onclick="document.getElementById('ป').play()" class="speech">ป</a>&nbsp;- fish&nbsp;(<audio id="ปลา" src="/speech/%E0%B8%9B%E0%B8%A5%E0%B8%B2.mp3" preload="auto"></audio><a onclick="document.getElementById('ปลา').play()" class="speech">ปลา</a>)<br>
<strong>mnemonic:&nbsp;</strong>Imagine a fishhook except it’s a bit squared up rather than round. The little circle on the hook can be the bait.</p>
<p><span style="font-size: 16px; line-height: 20px;">How many minutes did it take you to remember those few letters? &nbsp;The next step is to practice a bunch of the easier vowels with those 3 letters until you’ve mastered them before moving on to the next group of letters. &nbsp;My web course contains everything you need to master the rest of the alphabet, along with all the sounds and tones, in just 10 hours. That's over <b><ul>40 lessons</b></ul> with audio and flashcards.  &nbsp;What are you waiting for? &nbsp;</span></p>
<div class="gotosales cf">
<h4>Speak and Read Thai in 10 Hours!</h4>
<p><a href="/start-learning-thai-today/" onclick="mixpanel.track('Letters test three');"><img alt="" src="/wp-content/themes/news/images/lessonpack1.jpg"></a> Buy now and get <strong>$50 off!</strong></p>
<p class="oldprice">$147</p>
<p><img class="newprice" src="/wp-content/themes/news/images/newprice.png"></p>
<p><a class="learnmore" href="/start-learning-thai-today/" onclick="mixpanel.track('Letters test three');">Learn More</a></p>
</div>
</div>
</div>

    <div id="footer" class="footer">
      <div class="wrap">
        <div class="gototop">
          <p><a href="#wrap" rel="nofollow">Return to top of page</a></p>
        </div>

        <div class="creds">
          <p>Copyright 2013 Learn Thai From A White Guy</p>
        </div>
        <?php if(is_preview() ) : ?> 
        <p>test</p>
	<?php endif; ?>
      </div>
    </div>
  </div>
</html>
